import { NextResponse } from 'next/server';
import { getCdekDeliveryPoints } from '@/lib/cdek';

export async function GET(req: Request) {
    try {
        const { searchParams } = new URL(req.url);
        const cityCode = searchParams.get('cityCode');

        if (!cityCode) {
            return NextResponse.json({ error: 'cityCode is required' }, { status: 400 });
        }

        const points = await getCdekDeliveryPoints(parseInt(cityCode));
        return NextResponse.json(points);

    } catch (error: any) {
        console.error("CDEK PVZ Error:", error);
        return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
    }
}
