import { NextResponse } from 'next/server';
import { calculateCdekTariff, getCdekCityCode } from '@/lib/cdek';

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { city, quantity = 1 } = body;

        if (!city) {
            return NextResponse.json({ error: 'City is required' }, { status: 400 });
        }

        const cityCode = await getCdekCityCode(city);

        if (!cityCode) {
            return NextResponse.json({ error: `Could not find CDEK city code for ${city}` }, { status: 404 });
        }

        const weight = 500 * quantity;
        const calculation = await calculateCdekTariff(cityCode, weight);
        
        let courierPrice = null;
        let courierPeriod = null;
        let pvzPrice = null;
        let pvzPeriod = null;

        if (calculation.tariff_codes) {
            const courierTariff = calculation.tariff_codes.find((t: any) => t.tariff_code === 137);
            const pvzTariff = calculation.tariff_codes.find((t: any) => t.tariff_code === 136);

            if (courierTariff) {
                courierPrice = courierTariff.delivery_sum;
                courierPeriod = courierTariff.period_max === courierTariff.period_min 
                    ? `${courierTariff.period_min} дн.` 
                    : `${courierTariff.period_min}-${courierTariff.period_max} дн.`;
            }
            if (pvzTariff) {
                pvzPrice = pvzTariff.delivery_sum;
                pvzPeriod = pvzTariff.period_max === pvzTariff.period_min 
                    ? `${pvzTariff.period_min} дн.` 
                    : `${pvzTariff.period_min}-${pvzTariff.period_max} дн.`;
            }
        }

        return NextResponse.json({
            cityCode,
            courierPrice,
            courierPeriod,
            pvzPrice,
            pvzPeriod,
            raw: calculation
        });

    } catch (error: any) {
        console.error("CDEK Calculation Error:", error);
        return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
    }
}
