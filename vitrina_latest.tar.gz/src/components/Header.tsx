'use client';
import Link from 'next/link';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSession } from 'next-auth/react';
import { User, LogIn, ShoppingBag } from 'lucide-react';
import { useCartStore } from '@/store/useCartStore';
import { useState, useEffect } from 'react';

export default function Header() {
    const { lang, setLang, t } = useLanguage();
    const { data: session, status } = useSession();
    const { items, openCart } = useCartStore();
    const [mounted, setMounted] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        setMounted(true);
        setIsAdmin(localStorage.getItem('dimmianiAdmin') === 'true');
    }, []);

    const cartItemsCount = items.reduce((acc, item) => acc + item.quantity, 0);

    return (
        <header style={{
            position: 'sticky',
            top: 0,
            zIndex: 50,
            backgroundColor: 'var(--background)',
            borderBottom: '1px solid var(--card-border)',
            padding: '1rem 2rem'
        }}>
            <div className="container" style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: 0
            }}>

                {/* Logo and Brand */}
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <Link href="/" style={{ fontSize: '1.5rem', fontWeight: 800, letterSpacing: '0.05em' }}>
                        DIMMIANI
                    </Link>
                    <span style={{ fontSize: '0.75rem', opacity: 0.6, marginTop: '-2px' }}>
                        {t('brand_sub')}
                    </span>
                </div>

                {/* Navigation Links */}
                <nav style={{ display: 'flex', gap: '2rem', fontWeight: 500, fontSize: '0.9rem' }}>
                    <Link href="/">{t('nav_home')}</Link>
                    <Link href="/products">{t('nav_products')}</Link>
                    <Link href="/sale" style={{ color: 'var(--primary)', fontWeight: 700 }}>{t('nav_sale')}</Link>
                    <Link href="/returns">{t('nav_returns')}</Link>
                    <Link href="/contacts">{t('nav_contacts')}</Link>
                    <Link href="/blog">{t('nav_blog')}</Link>
                    <Link href="/terms">{t('nav_terms')}</Link>
                </nav>

                {/* Language Toggle and Admin */}
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                    {isAdmin && (
                    <button
                        onClick={openCart}
                        style={{
                            position: 'relative',
                            background: 'transparent',
                            border: 'none',
                            cursor: 'pointer',
                            color: 'var(--foreground)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}
                    >
                        <ShoppingBag size={22} />
                        {mounted && cartItemsCount > 0 && (
                            <span style={{
                                position: 'absolute',
                                top: '-6px',
                                right: '-8px',
                                backgroundColor: '#ff3b30',
                                color: 'white',
                                fontSize: '0.65rem',
                                fontWeight: 'bold',
                                width: '18px',
                                height: '18px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderRadius: '50%'
                            }}>
                                {cartItemsCount}
                            </span>
                        )}
                    </button>
                    )}
                    
                    <button
                        onClick={() => setLang(lang === 'RU' ? 'KZ' : 'RU')}
                        style={{
                            background: 'transparent',
                            border: '1px solid var(--primary)',
                            borderRadius: '20px',
                            padding: '0.3rem 0.8rem',
                            fontSize: '0.8rem',
                            fontWeight: 600,
                            color: 'var(--primary)',
                            cursor: 'pointer',
                        }}
                    >
                        {lang}
                    </button>
                    {status === 'loading' ? (
                        <div style={{ width: '30px', height: '30px', borderRadius: '50%', backgroundColor: 'var(--card-border)' }} />
                    ) : session ? (
                        <Link
                            href="/profile"
                            style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                background: 'var(--primary)',
                                color: 'var(--primary-foreground)',
                                borderRadius: '50%',
                                width: '32px',
                                height: '32px',
                                textDecoration: 'none',
                                transition: 'transform 0.2s',
                            }}
                            onMouseOver={e => (e.currentTarget.style.transform = 'scale(1.05)')}
                            onMouseOut={e => (e.currentTarget.style.transform = 'scale(1)')}
                        >
                            <User size={16} />
                        </Link>
                    ) : (
                        <Link
                            href="/auth/login"
                            style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '0.4rem',
                                background: 'transparent',
                                border: '1px solid var(--primary)',
                                color: 'var(--primary)',
                                borderRadius: '20px',
                                padding: '0.3rem 0.9rem',
                                fontSize: '0.8rem',
                                fontWeight: 600,
                                textDecoration: 'none',
                            }}
                        >
                            <LogIn size={14} />
                            {t('login')}
                        </Link>
                    )}

                    <Link
                        href="https://admin.dimmiani.kz"
                        style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.4rem',
                            background: 'transparent',
                            border: '1px solid var(--card-border)',
                            borderRadius: '20px',
                            padding: '0.3rem 0.9rem',
                            fontSize: '0.8rem',
                            fontWeight: 500,
                            color: 'var(--foreground)',
                            opacity: 0.65,
                            textDecoration: 'none',
                            transition: 'opacity 0.2s',
                        }}
                        onMouseOver={e => (e.currentTarget.style.opacity = '1')}
                        onMouseOut={e => (e.currentTarget.style.opacity = '0.65')}
                    >
                        🔒 {t('nav_employees')}
                    </Link>
                </div>

            </div>
        </header>
    );
}

