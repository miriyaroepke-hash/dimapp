import { NextRequest, NextResponse } from 'next/server';
import { v2 as cloudinary } from 'cloudinary';
import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';

// Allow large video uploads (up to 200MB)
export const maxDuration = 120; // 2 min timeout

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

function uploadToCloudinary(buffer: Buffer, options: object): Promise<any> {
    return new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(options, (error, result) => {
            if (error) return reject(error);
            resolve(result);
        });
        stream.end(buffer);
    });
}

export async function POST(req: NextRequest) {
    cloudinary.config({
        cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
        api_key: process.env.CLOUDINARY_API_KEY,
        api_secret: process.env.CLOUDINARY_API_SECRET,
    });

    try {
        const formData = await req.formData();
        const file = formData.get('media') as File | null;
        const fieldName = formData.get('fieldName') as string | null;

        if (!file || !fieldName) {
            return NextResponse.json({ error: 'Missing media or fieldName' }, { status: 400 });
        }

        const arrayBuffer = await file.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        const isVideo = file.type.startsWith('video/');

        const result = await uploadToCloudinary(buffer, {
            folder: 'inventory_showcase_content',
            resource_type: isVideo ? 'video' : 'image',
        });

        // Update or Create SiteContent in Prisma
        let content = await prisma.siteContent.findFirst();
        if (content) {
            content = await prisma.siteContent.update({
                where: { id: content.id },
                data: { [fieldName]: result.secure_url },
            });
        } else {
            content = await prisma.siteContent.create({
                data: {
                    text_ru: "Curated\nCollection.",
                    text_kz: "Таңдаулы\nКоллекция.",
                    [fieldName]: result.secure_url,
                }
            });
        }

        return NextResponse.json({ success: true, url: result.secure_url });
    } catch (error: any) {
        console.error('Content upload error:', error);
        const message = error?.message || JSON.stringify(error);
        return NextResponse.json({ error: 'Failed to upload media', details: message }, { status: 500 });
    }
}
