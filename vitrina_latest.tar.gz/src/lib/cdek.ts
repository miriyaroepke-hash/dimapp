const CDEK_API_URL = "https://api.cdek.ru/v2";

let accessToken: string | null = null;
let tokenExpiry: number = 0;

export async function getAccessToken() {
    if (accessToken && Date.now() < tokenExpiry) {
        return accessToken;
    }

    const account = process.env.CDEK_ACCOUNT;
    const password = process.env.CDEK_PASSWORD;

    if (!account || !password) {
        throw new Error("CDEK credentials not configured in env");
    }

    const params = new URLSearchParams();
    params.append("grant_type", "client_credentials");
    params.append("client_id", account);
    params.append("client_secret", password);

    const response = await fetch(`${CDEK_API_URL}/oauth/token`, {
        method: "POST",
        body: params,
        cache: 'no-store'
    });

    if (!response.ok) {
        const error = await response.text();
        throw new Error(`CDEK Auth Failed: ${error}`);
    }

    const data = await response.json();
    accessToken = data.access_token;
    tokenExpiry = Date.now() + (data.expires_in - 60) * 1000;

    return accessToken;
}

export async function getCdekCityCode(cityName: string): Promise<number | null> {
    const token = await getAccessToken();

    const params = new URLSearchParams({
        city: cityName,
        country_codes: "KZ,RU" 
    });

    const response = await fetch(`${CDEK_API_URL}/location/cities?${params}`, {
        method: "GET",
        headers: {
            "Authorization": `Bearer ${token}`
        }
    });

    if (!response.ok) return null;

    const cities = await response.json();
    if (cities && cities.length > 0) {
        // Return the first match's code
        return cities[0].code;
    }
    return null;
}

export async function calculateCdekTariff(toCityCode: number, weightInGrams: number = 500) {
    const token = await getAccessToken();

    const payload = {
        type: "1", // Online store
        from_location: {
            code: 4756 // Almaty
        },
        to_location: {
            code: toCityCode
        },
        packages: [
            {
                weight: weightInGrams, // e.g. 500g per item
                length: 21,
                width: 27,
                height: 6
            }
        ]
    };

    const response = await fetch(`${CDEK_API_URL}/calculator/tarifflist`, {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });

    const body = await response.json();

    if (!response.ok) {
        throw new Error(`CDEK Calculator Failed: ${JSON.stringify(body)}`);
    }

    return body;
}

export async function getCdekDeliveryPoints(cityCode: number) {
    const token = await getAccessToken();

    const params = new URLSearchParams({
        city_code: cityCode.toString(),
        type: 'PVZ' // Point of issue
    });

    const response = await fetch(`${CDEK_API_URL}/deliverypoints?${params.toString()}`, {
        method: "GET",
        headers: {
            "Authorization": `Bearer ${token}`
        }
    });

    if (!response.ok) return [];

    const points = await response.json();
    return points;
}
