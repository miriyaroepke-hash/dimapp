import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';
import ProductsClient from './ProductsClient';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

export const revalidate = 60;

async function getProducts() {
    let retries = 3;
    while (retries > 0) {
        try {
            const storefrontProducts = await prisma.storefrontProduct.findMany({
                where: { isActive: true },
                include: {
                    products: {
                        where: { quantity: { gt: 0 } },
                        orderBy: { price: 'asc' }
                    }
                },
                orderBy: { createdAt: 'desc' },
            });
            
            // Filter out storefront products that have no available sizes in stock
            return storefrontProducts.filter(sp => sp.products.length > 0);
        } catch (error) {
            retries--;
            console.error(`Database connection error, retries left: ${retries}`, error);
            if (retries === 0) throw error;
            await new Promise(res => setTimeout(res, 1500)); // wait before retry
        }
    }
    return [];
}

export default async function ProductsPage() {
    const storefrontProducts = await getProducts();
    return <ProductsClient products={storefrontProducts} />;
}
