import CheckoutClient from './CheckoutClient';
import { getServerSession } from "next-auth/next";
import { authOptions } from "../api/auth/[...nextauth]/route";

export default async function CheckoutPage() {
    const session = await getServerSession(authOptions);
    
    return <CheckoutClient session={session} />;
}
