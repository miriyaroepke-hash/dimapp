'use client';

import ProductCard from '@/components/ProductCard';
import { useLanguage } from '@/contexts/LanguageContext';
import { useState, useMemo } from 'react';

export default function ProductsClient({ products }: { products: any[] }) {
    const { t } = useLanguage();
    const [search, setSearch] = useState('');
    const [selectedSize, setSelectedSize] = useState('');

    // Collect all unique sizes across all products
    const allSizes = useMemo(() => {
        const sizeSet = new Set<string>();
        products.forEach(sp => {
            sp.products?.forEach((p: any) => {
                if (p.size) sizeSet.add(p.size);
            });
        });
        // Sort sizes: numeric first, then string
        return Array.from(sizeSet).sort((a, b) => {
            const na = parseFloat(a), nb = parseFloat(b);
            if (!isNaN(na) && !isNaN(nb)) return na - nb;
            return a.localeCompare(b);
        });
    }, [products]);

    const filtered = useMemo(() => {
        return products.filter(sp => {
            const matchesName = !search || sp.name.toLowerCase().includes(search.toLowerCase());
            const matchesSize = !selectedSize || sp.products?.some((p: any) => p.size === selectedSize && p.quantity > 0);
            return matchesName && matchesSize;
        });
    }, [products, search, selectedSize]);

    return (
        <main className="container animate-fade-in" style={{ padding: '4rem 2rem', paddingTop: '6rem' }}>
            <div style={{ maxWidth: '1200px', margin: '0 auto' }}>

                <section id="products">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '1.5rem' }}>
                        <h2 style={{ fontSize: '2rem', fontWeight: 800 }}>{t('nav_products')}</h2>
                        <span style={{ fontSize: '1rem', opacity: 0.6 }}>{filtered.length} {t('items_count')}</span>
                    </div>

                    {/* Search + Size Filter */}
                    <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap', alignItems: 'center' }}>
                        <div style={{ position: 'relative', flex: '1 1 240px', minWidth: '200px' }}>
                            <svg
                                viewBox="0 0 24 24"
                                style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: '16px', height: '16px', opacity: 0.4, pointerEvents: 'none' }}
                                fill="none" stroke="currentColor" strokeWidth={2}
                            >
                                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
                            </svg>
                            <input
                                type="text"
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                                placeholder="Поиск по названию..."
                                style={{
                                    width: '100%',
                                    padding: '0.6rem 0.75rem 0.6rem 2.25rem',
                                    borderRadius: '10px',
                                    border: '1px solid #ddd',
                                    fontSize: '0.9rem',
                                    background: 'var(--card-bg, #fff)',
                                    color: 'inherit',
                                    outline: 'none',
                                    boxSizing: 'border-box',
                                }}
                            />
                        </div>

                        {allSizes.length > 0 && (
                            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
                                <button
                                    onClick={() => setSelectedSize('')}
                                    style={{
                                        padding: '0.45rem 0.9rem',
                                        borderRadius: '8px',
                                        border: `1px solid ${!selectedSize ? '#111' : '#ddd'}`,
                                        backgroundColor: !selectedSize ? '#111' : 'transparent',
                                        color: !selectedSize ? '#fff' : 'inherit',
                                        fontSize: '0.85rem',
                                        fontWeight: 500,
                                        cursor: 'pointer',
                                        transition: 'all 0.15s',
                                    }}
                                >
                                    Все
                                </button>
                                {allSizes.map(size => (
                                    <button
                                        key={size}
                                        onClick={() => setSelectedSize(size === selectedSize ? '' : size)}
                                        style={{
                                            padding: '0.45rem 0.9rem',
                                            borderRadius: '8px',
                                            border: `1px solid ${selectedSize === size ? '#111' : '#ddd'}`,
                                            backgroundColor: selectedSize === size ? '#111' : 'transparent',
                                            color: selectedSize === size ? '#fff' : 'inherit',
                                            fontSize: '0.85rem',
                                            fontWeight: 500,
                                            cursor: 'pointer',
                                            transition: 'all 0.15s',
                                        }}
                                    >
                                        {size}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {filtered.length === 0 ? (
                        <p style={{ opacity: 0.5 }}>Ничего не найдено</p>
                    ) : (
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                            gap: '2rem'
                        }}>
                            {filtered.map((storeProduct: any) => (
                                <ProductCard key={storeProduct.id} storeProduct={storeProduct} />
                            ))}
                        </div>
                    )}
                </section>
            </div>
        </main>
    );
}
