import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';
import { v2 as cloudinary } from 'cloudinary';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
});

function uploadToCloudinary(buffer: Buffer, options: object): Promise<any> {
    return new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(options, (error, result) => {
            if (error) return reject(error);
            resolve(result);
        });
        stream.end(buffer);
    });
}

// GET all storefront products with their variants
export async function GET() {
    try {
        const products = await prisma.storefrontProduct.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                products: {
                    select: { id: true, name: true, size: true, price: true, sku: true }
                }
            }
        });
        return NextResponse.json(products);
    } catch (error) {
        console.error('Failed to fetch storefront products:', error);
        return NextResponse.json({ error: 'Failed to fetch storefront products' }, { status: 500 });
    }
}

// POST update storefront product (text fields + image upload)
export async function POST(req: NextRequest) {
    try {
        const contentType = req.headers.get('content-type') || '';

        if (contentType.includes('multipart/form-data')) {
            // Image upload
            const formData = await req.formData();
            const file = formData.get('image') as File | null;
            const productId = parseInt(formData.get('productId') as string);
            const imageIndex = parseInt(formData.get('imageIndex') as string || '0');

            if (!file || !productId) {
                return NextResponse.json({ error: 'Missing image or productId' }, { status: 400 });
            }

            const arrayBuffer = await file.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);

            const result = await uploadToCloudinary(buffer, {
                folder: 'inventory_storefront',
                resource_type: 'image',
            });

            const storefrontProduct = await prisma.storefrontProduct.findUnique({ where: { id: productId } });
            if (!storefrontProduct) return NextResponse.json({ error: 'Product not found' }, { status: 404 });

            const images = [...(storefrontProduct.images || [])];
            images[imageIndex] = result.secure_url;

            const updated = await prisma.storefrontProduct.update({
                where: { id: productId },
                data: {
                    image: images[0] || storefrontProduct.image,
                    images,
                },
                include: { products: { select: { id: true, name: true, size: true, price: true, sku: true } } }
            });

            return NextResponse.json({ success: true, product: updated, url: result.secure_url });
        } else {
            // JSON text update
            const data = await req.json();
            const { id, name, description, discountPrice, isActive } = data;

            const updated = await prisma.storefrontProduct.update({
                where: { id },
                data: {
                    ...(name !== undefined && { name }),
                    ...(description !== undefined && { description }),
                    ...(discountPrice !== undefined && { discountPrice: discountPrice ? parseFloat(discountPrice) : null }),
                    ...(isActive !== undefined && { isActive }),
                },
                include: { products: { select: { id: true, name: true, size: true, price: true, sku: true } } }
            });

            return NextResponse.json({ success: true, product: updated });
        }
    } catch (error: any) {
        console.error('Storefront product update error:', error);
        return NextResponse.json({ error: error.message || 'Failed to update storefront product' }, { status: 500 });
    }
}
