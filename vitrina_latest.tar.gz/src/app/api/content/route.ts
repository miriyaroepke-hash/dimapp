import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

export async function GET() {
    try {
        const content = await prisma.siteContent.findFirst();
        return NextResponse.json(content || {});
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch site content' }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    try {
        const data = await req.json();

        let content = await prisma.siteContent.findFirst();
        if (content) {
            content = await prisma.siteContent.update({
                where: { id: content.id },
                data: {
                    text_ru: data.text_ru !== undefined ? data.text_ru : content.text_ru,
                    text_kz: data.text_kz !== undefined ? data.text_kz : content.text_kz,
                    photo1: data.photo1 !== undefined ? data.photo1 : content.photo1,
                    photo2: data.photo2 !== undefined ? data.photo2 : content.photo2,
                    video_url: data.video_url !== undefined ? data.video_url : content.video_url,
                    returns_ru: data.returns_ru !== undefined ? data.returns_ru : content.returns_ru,
                    returns_kz: data.returns_kz !== undefined ? data.returns_kz : content.returns_kz,
                    contacts_ru: data.contacts_ru !== undefined ? data.contacts_ru : content.contacts_ru,
                    contacts_kz: data.contacts_kz !== undefined ? data.contacts_kz : content.contacts_kz,
                }
            });
        } else {
            content = await prisma.siteContent.create({
                data: {
                    text_ru: data.text_ru || "Curated\nCollection.",
                    text_kz: data.text_kz || "Таңдаулы\nКоллекция.",
                    photo1: data.photo1,
                    photo2: data.photo2,
                    video_url: data.video_url,
                    returns_ru: data.returns_ru,
                    returns_kz: data.returns_kz,
                    contacts_ru: data.contacts_ru,
                    contacts_kz: data.contacts_kz,
                }
            });
        }

        return NextResponse.json(content);
    } catch (error) {
        console.error(error);
        return NextResponse.json({ error: 'Failed to update site content' }, { status: 500 });
    }
}
