'use client';

import { useLanguage } from '@/contexts/LanguageContext';

interface SiteContent {
    text_ru: string | null;
    text_kz: string | null;
    video_url: string | null;
    video2_url: string | null;
    video3_url: string | null;
}

export default function HomeClient({ content }: { content: SiteContent | null }) {
    const { lang, t } = useLanguage();

    // Fallback default content
    const heroText = lang === 'RU'
        ? (content?.text_ru || t('hero_title'))
        : (content?.text_kz || t('hero_title'));

    const vid1 = content?.video_url; 
    const vid2 = content?.video2_url;
    const vid3 = content?.video3_url;

    return (
        <main className="container animate-fade-in" style={{ padding: '4rem 2rem', paddingTop: '8rem' }}>
            <div style={{ maxWidth: '1200px', margin: '0 auto' }}>

                {/* HERO TEXT */}
                <h1 style={{
                    fontSize: 'clamp(2.5rem, 6vw, 5rem)',
                    fontWeight: 800,
                    lineHeight: 1.1,
                    letterSpacing: '-0.04em',
                    marginBottom: '4rem',
                    maxWidth: '800px',
                    whiteSpace: 'pre-line'
                }}>
                    {heroText}
                </h1>


                {/* MEDIA GRID: 3 Videos */}
                <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '2rem',
                    marginBottom: '6rem'
                }}>
                    {/* Big Video 1 — horizontal 16:9 */}
                    <div style={{
                        width: '100%',
                        aspectRatio: '16/9',
                        backgroundColor: '#111',
                        borderRadius: 'var(--radius)',
                        overflow: 'hidden',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff'
                    }}>
                        {vid1 ? (
                            <video src={vid1} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        ) : (
                            <p style={{ opacity: 0.5 }}>[Главное Видео 1]</p>
                        )}
                    </div>

                    {/* Bottom Two Videos Side-By-Side (16:9) */}
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr',
                        gap: '2rem'
                    }}>
                        <div style={{
                            aspectRatio: '9/16',
                            backgroundColor: '#111',
                            borderRadius: 'var(--radius)',
                            overflow: 'hidden',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff'
                        }}>
                            {vid2 ? (
                                <video src={vid2} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                            ) : (
                                <p style={{ opacity: 0.5, textAlign: 'center' }}>[Видео 2]</p>
                            )}
                        </div>

                        <div style={{
                            aspectRatio: '9/16',
                            backgroundColor: '#111',
                            borderRadius: 'var(--radius)',
                            overflow: 'hidden',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff'
                        }}>
                            {vid3 ? (
                                <video src={vid3} autoPlay loop muted playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                            ) : (
                                <p style={{ opacity: 0.5, textAlign: 'center' }}>[Видео 3]</p>
                            )}
                        </div>
                    </div>
                </div>

            </div>
        </main>
    );
}
