"use client";

import { useCartStore } from "@/store/useCartStore";
import { X, Trash2, Plus, Minus, ShoppingBag } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

export default function CartSidebar() {
    const { items, isOpen, closeCart, updateQuantity, removeItem } = useCartStore();
    const { t } = useLanguage();
    
    // Prevent hydration errors by only rendering cart contents on client side
    const [mounted, setMounted] = useState(false);
    useEffect(() => {
        setMounted(true);
    }, []);

    if (!isOpen) return null;

    const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);

    return (
        <>
            {/* Overlay */}
            <div 
                style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    width: '100vw',
                    height: '100vh',
                    backgroundColor: 'rgba(0,0,0,0.5)',
                    zIndex: 9998,
                    opacity: isOpen ? 1 : 0,
                    transition: 'opacity 0.3s ease',
                }}
                onClick={closeCart}
            />

            {/* Sidebar */}
            <div style={{
                position: 'fixed',
                top: 0,
                right: 0,
                width: '100%',
                maxWidth: '430px',
                height: '100vh',
                backgroundColor: 'var(--background)',
                zIndex: 9999,
                boxShadow: '-4px 0 24px rgba(0,0,0,0.1)',
                display: 'flex',
                flexDirection: 'column',
                transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
                animation: 'slideIn 0.3s forwards',
            }}>
                <style dangerouslySetInnerHTML={{__html: `
                    @keyframes slideIn {
                        from { transform: translateX(100%); }
                        to { transform: translateX(0); }
                    }
                `}} />
                
                {/* Header */}
                <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '1.5rem',
                    borderBottom: '1px solid var(--card-border)'
                }}>
                    <h2 style={{ fontSize: '1.3rem', fontWeight: 700, margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <ShoppingBag size={20} />
                        {t('cart')}
                    </h2>
                    <button 
                        onClick={closeCart}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--foreground)' }}
                    >
                        <X size={24} />
                    </button>
                </div>

                {/* Body / Items */}
                <div style={{ flex: 1, overflowY: 'auto', padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    {!mounted || items.length === 0 ? (
                        <div style={{ textAlign: 'center', opacity: 0.5, marginTop: '2rem' }}>
                            <ShoppingBag size={48} style={{ margin: '0 auto 1rem auto' }} />
                            <p>{t('cart_empty')}</p>
                            <button 
                                onClick={closeCart}
                                style={{
                                    marginTop: '1rem',
                                    padding: '0.8rem 1.5rem',
                                    border: '1px solid var(--card-border)',
                                    borderRadius: '8px',
                                    background: 'transparent',
                                    color: 'var(--foreground)',
                                    cursor: 'pointer',
                                    fontWeight: 500
                                }}
                            >
                                {t('continue_shopping')}
                            </button>
                        </div>
                    ) : (
                        items.map((item) => (
                            <div key={item.id} style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid var(--card-border)', paddingBottom: '1.5rem' }}>
                                <div style={{ width: '80px', height: '100px', backgroundColor: '#f5f5f5', borderRadius: '8px', overflow: 'hidden' }}>
                                    {item.image && <img src={item.image} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                                </div>
                                <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                        <h4 style={{ fontSize: '1rem', fontWeight: 600, margin: 0, lineHeight: 1.2 }}>{item.name}</h4>
                                        <button 
                                            onClick={() => removeItem(item.id)}
                                            style={{ background: 'none', border: 'none', color: '#ff3b30', cursor: 'pointer', padding: '0.2rem' }}
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                    <p style={{ fontSize: '0.85rem', opacity: 0.6, margin: '0.2rem 0 0 0' }}>
                                        {t('size')}: <span style={{ fontWeight: 600 }}>{item.size || 'Уни'}</span>
                                    </p>
                                    <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <div style={{ 
                                            display: 'flex', 
                                            alignItems: 'center', 
                                            border: '1px solid var(--card-border)',
                                            borderRadius: '6px'
                                        }}>
                                            <button 
                                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                                style={{ background: 'none', border: 'none', padding: '0.3rem 0.5rem', cursor: 'pointer', opacity: item.quantity <= 1 ? 0.3 : 1 }}
                                                disabled={item.quantity <= 1}
                                            >
                                                <Minus size={14} />
                                            </button>
                                            <span style={{ fontSize: '0.9rem', width: '20px', textAlign: 'center', fontWeight: 500 }}>{item.quantity}</span>
                                            <button 
                                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                                style={{ background: 'none', border: 'none', padding: '0.3rem 0.5rem', cursor: 'pointer' }}
                                            >
                                                <Plus size={14} />
                                            </button>
                                        </div>
                                        <p style={{ fontWeight: 700, margin: 0 }}>
                                            {(item.price * item.quantity).toLocaleString('ru-RU')} ₸
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* Footer */}
                {mounted && items.length > 0 && (
                    <div style={{ padding: '1.5rem', borderTop: '1px solid var(--card-border)', backgroundColor: 'var(--card-bg)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', fontSize: '1.1rem', fontWeight: 600 }}>
                            <span>{t('subtotal_prefix')}</span>
                            <span>{subtotal.toLocaleString('ru-RU')} ₸</span>
                        </div>
                        <p style={{ fontSize: '0.8rem', opacity: 0.6, textAlign: 'center', marginBottom: '1rem' }}>
                            {t('delivery_calc_note')}
                        </p>
                        <Link 
                            href="/checkout" 
                            onClick={closeCart}
                            style={{
                                display: 'block',
                                width: '100%',
                                padding: '1rem',
                                backgroundColor: 'var(--primary)',
                                color: 'var(--primary-foreground)',
                                textAlign: 'center',
                                borderRadius: '8px',
                                textDecoration: 'none',
                                fontWeight: 700,
                                fontSize: '1.1rem'
                            }}
                        >
                            {t('checkout')}
                        </Link>
                    </div>
                )}
            </div>
        </>
    );
}
