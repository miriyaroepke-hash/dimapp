import NextAuth, { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export const authOptions: NextAuthOptions = {
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                phone: { label: "Телефон", type: "text", placeholder: "+7..." },
                password: { label: "Пароль", type: "password" },
            },
            async authorize(credentials) {
                if (!credentials?.phone || !credentials?.password) {
                    throw new Error("Необходимо указать номер телефона и пароль");
                }

                const user = await prisma.customer.findUnique({
                    where: { phone: credentials.phone },
                });

                if (!user) {
                    throw new Error("Пользователь с таким номером не найден");
                }

                const isValid = await bcrypt.compare(credentials.password, user.password);

                if (!isValid) {
                    throw new Error("Неверный пароль");
                }

                return {
                    id: user.id,
                    name: `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.phone,
                    phone: user.phone,
                    email: user.email,
                };
            },
        }),
    ],
    session: {
        strategy: "jwt",
    },
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
                token.id = user.id;
                token.phone = (user as any).phone;
            }
            return token;
        },
        async session({ session, token }) {
            if (token) {
                if (session.user) {
                    (session.user as any).id = token.id;
                    (session.user as any).phone = token.phone;
                }
            }
            return session;
        },
    },
    pages: {
        signIn: "/auth/login",
    },
    secret: process.env.NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
