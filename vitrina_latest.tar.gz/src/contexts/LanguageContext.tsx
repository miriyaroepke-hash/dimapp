'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'RU' | 'KZ';

// Simple Dictionary
const translations = {
    RU: {
        brand_sub: 'Казахстанский бренд женской одежды',
        nav_home: 'Главная',
        nav_products: 'Товары',
        nav_returns: 'Возвраты',
        nav_contacts: 'Контакты',
        nav_blog: 'Блог',
        nav_terms: 'Условия заказа и доставки',
        section_in_development: 'Раздел находится в разработке.',
        add_to_cart: 'В корзину',
        order_whatsapp: 'Заказать через WhatsApp',
        hero_title: 'Curated\nCollection.',
        hero_desc: 'Explore our premium inventory carefully selected for quality and style. Currently in stock and ready to order.',
        in_stock_now: 'В наличии',
        items_count: 'товаров',
        no_products: 'Нет товаров в наличии.',
        size: 'Размер',
        admin: 'Админ',
        upload_image: 'Загрузить фото',
        uploading: 'Загрузка...',
        admin_login: 'Вход для администратора',
        password: 'Пароль',
        login: 'Войти',
        nav_sale: 'СКИДКИ',
        login_title: 'С возвращением',
        login_sub: 'Войдите в личный кабинет',
        phone: 'Номер телефона',
        phone_req: 'Номер телефона *',
        no_account: 'Нет аккаунта?',
        register_link: 'Зарегистрироваться',
        register_title: 'Создать аккаунт',
        register_sub: 'Присоединяйтесь к нам, чтобы управлять покупками и заказами',
        first_name: 'Имя',
        last_name: 'Фамилия',
        pwd_req: 'Пароль *',
        pwd_min: 'Минимум 6 символов',
        register_btn: 'Зарегистрироваться',
        have_account: 'Уже есть аккаунт?',
        aliya: 'Алия',
        akhmetova: 'Ахметова',
        nav_employees: 'Сотрудникам',
        buy_on_kaspi: 'Покупки на Kaspi.kz',
        buy_on_halyk: 'Покупки на Halyk Market',
        // Checkout & Cart
        cart: 'Корзина',
        cart_empty: 'Ваша корзина пуста',
        continue_shopping: 'Продолжить покупки',
        subtotal_prefix: 'Итого:',
        delivery_calc_note: 'Стоимость доставки рассчитывается на этапе оформления',
        checkout: 'Оформить заказ',
        checkout_title: 'Оформление заказа',
        checkout_contacts: 'Контактные данные',
        checkout_name: 'Ваше Имя *',
        checkout_phone: 'Ваш Телефон *',
        checkout_city_title: 'Город доставки',
        checkout_city_placeholder: 'Город (например: Алматы, Астана) *',
        checkout_city_btn: 'Подтвердить город',
        checkout_delivery_title: 'Способ доставки в г.',
        pickup_title: 'Самовывоз (Алматы)',
        pickup_desc: 'Бесплатно. Заберите из нашего магазина.',
        yandex_title: 'Яндекс / InDriver доставка',
        yandex_desc: 'Оплата курьеру при получении по тарифу.',
        kazpost_title: 'Казпочта',
        kazpost_desc: 'Доставка до почтового отделения.',
        cdek_courier_title: 'Курьер СДЭК (до двери)',
        cdek_pvz_title: 'Пункт выдачи СДЭК',
        cdek_est: 'Ориентировочно:',
        cdek_pvz_note: 'Мы отправим заказ в выбранный пункт выдачи.',
        checkout_address_title: 'Точный адрес',
        checkout_street: 'Улица, Район *',
        checkout_house: 'Дом *',
        checkout_apt: 'Квартира',
        checkout_comment: 'Комментарий к заказу (необязательно)',
        checkout_payment_title: 'Способ оплаты',
        kaspi_bank_title: 'Kaspi Bank (Рассрочка, Кредит, Red, Gold)',
        halyk_bank_title: 'Halyk Bank',
        checkout_order: 'Ваш заказ',
        checkout_products: 'Товары',
        checkout_delivery_cost: 'Доставка:',
        checkout_total: 'К оплате:',
        checkout_submit: 'Оформить заказ',
        checkout_submitting: 'Оформляем...',
        checkout_btn_disabled: '* Сначала выберите способ доставки',
        success_thanks: 'Спасибо за заказ!',
        success_wait: 'ожидает подтверждения менеджером.',
        success_order_info: 'Информация об оплате',
        success_amount: 'Сумма к оплате:',
        success_chosen_payment: 'Выбрана оплата:',
        success_kaspi_msg: 'Наш менеджер свяжется с вами в ближайшее время и выставит счет на оплату в приложении Kaspi.kz.',
        success_halyk_msg: 'Наш менеджер свяжется с вами в ближайшее время для выставления счета через Halyk.',
        success_whatsapp: 'Написать в WhatsApp',
        cdek_loading: 'Загрузка...',
    },
    KZ: {
        brand_sub: 'Қазақстандық әйелдер киімі бренді',
        nav_home: 'Басты бет',
        nav_products: 'Тауарлар',
        nav_returns: 'Қайтару',
        nav_contacts: 'Байланыс',
        nav_blog: 'Блог',
        nav_terms: 'Тапсырыс және жеткізу шарттары',
        section_in_development: 'Бөлім әзірленуде.',
        add_to_cart: 'Себетке қосу',
        order_whatsapp: 'WhatsApp арқылы тапсырыс беру',
        hero_title: 'Таңдаулы\nКоллекция.',
        hero_desc: 'Сапасы мен стилі үшін мұқият таңдалған біздің премиум инвентарымызды зерттеңіз. Қазір қол жетімді және тапсырыс беруге дайын.',
        in_stock_now: 'Қол жетімді',
        items_count: 'тауар',
        no_products: 'Қол жетімді тауарлар жоқ.',
        size: 'Өлшемі',
        admin: 'Админ',
        upload_image: 'Сурет жүктеу',
        uploading: 'Жүктелуде...',
        admin_login: 'Әкімшіге кіру',
        password: 'Құпия сөз',
        login: 'Кіру',
        nav_sale: 'ЖЕҢІЛДІКТЕР',
        login_title: 'Қайта оралуыңызбен',
        login_sub: 'Жеке кабинетке кіріңіз',
        phone: 'Телефон нөмірі',
        phone_req: 'Телефон нөмірі *',
        no_account: 'Аккаунт жоқ па?',
        register_link: 'Тіркелу',
        register_title: 'Аккаунт құру',
        register_sub: 'Сатып алулар мен тапсырыстарды басқару үшін бізге қосылыңыз',
        first_name: 'Аты',
        last_name: 'Тегі',
        pwd_req: 'Құпия сөз *',
        pwd_min: 'Кем дегенде 6 таңба',
        register_btn: 'Тіркелу',
        have_account: 'Аккаунтыңыз бар ма?',
        aliya: 'Әлия',
        akhmetova: 'Ахметова',
        nav_employees: 'Қызметкерлерге',
        buy_on_kaspi: 'Kaspi.kz-тен сатып алу',
        buy_on_halyk: 'Halyk Market-тен сатып алу',
        // Checkout & Cart
        cart: 'Себет',
        cart_empty: 'Сіздің себетіңіз бос',
        continue_shopping: 'Сатып алуды жалғастыру',
        subtotal_prefix: 'Барлығы:',
        delivery_calc_note: 'Жеткізу құны рәсімдеу кезеңінде есептеледі',
        checkout: 'Тапсырыс беру',
        checkout_title: 'Тапсырысты рәсімдеу',
        checkout_contacts: 'Байланыс мәліметтері',
        checkout_name: 'Атыңыз *',
        checkout_phone: 'Телефоныңыз *',
        checkout_city_title: 'Жеткізу қаласы',
        checkout_city_placeholder: 'Қала (мысалы: Алматы, Астана) *',
        checkout_city_btn: 'Қаланы растау',
        checkout_delivery_title: 'Жеткізу тәсілі',
        pickup_title: 'Алып кету (Алматы)',
        pickup_desc: 'Тегін. Біздің дүкеннен алып кетіңіз.',
        yandex_title: 'Яндекс / InDriver жеткізу',
        yandex_desc: 'Тариф бойынша курьерге алған кезде төлеу.',
        kazpost_title: 'Қазпошта',
        kazpost_desc: 'Пошта бөлімшесіне дейін жеткізу.',
        cdek_courier_title: 'СДЭК курьері (есікке дейін)',
        cdek_pvz_title: 'СДЭК беру пункті',
        cdek_est: 'Шамамен:',
        cdek_pvz_note: 'Біз тапсырысты таңдалған беру пунктіне жібереміз.',
        checkout_address_title: 'Нақты мекенжай',
        checkout_street: 'Көше, Ауданы *',
        checkout_house: 'Үй *',
        checkout_apt: 'Пәтер',
        checkout_comment: 'Тапсырысқа пікір (міндетті емес)',
        checkout_payment_title: 'Төлем тәсілі',
        kaspi_bank_title: 'Kaspi Bank (Бөліп төлеу, Несие, Red, Gold)',
        halyk_bank_title: 'Halyk Bank',
        checkout_order: 'Сіздің тапсырысыңыз',
        checkout_products: 'Тауарлар',
        checkout_delivery_cost: 'Жеткізу:',
        checkout_total: 'Төлемге:',
        checkout_submit: 'Тапсырыс беру',
        checkout_submitting: 'Рәсімделуде...',
        checkout_btn_disabled: '* Алдымен жеткізу тәсілін таңдаңыз',
        success_thanks: 'Тапсырысыңыз үшін рахмет!',
        success_wait: 'менеджердің растауын күтуде.',
        success_order_info: 'Төлем туралы ақпарат',
        success_amount: 'Төлеуге жататын сома:',
        success_chosen_payment: 'Таңдалған төлем түрі:',
        success_kaspi_msg: 'Біздің менеджер жақын арада сізбен байланысып, Kaspi.kz қосымшасында төлемге шот ұсынады.',
        success_halyk_msg: 'Біздің менеджер Halyk арқылы шот ұсыну үшін жақын арада сізбен байланысады.',
        success_whatsapp: 'WhatsApp-қа жазу',
        cdek_loading: 'Жүктелуде...',
    }
};

type TranslationKey = keyof typeof translations.RU;

interface LanguageContextType {
    lang: Language;
    setLang: (lang: Language) => void;
    t: (key: TranslationKey) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
    const [lang, setLang] = useState<Language>('RU');

    const t = (key: TranslationKey) => {
        return translations[lang][key] || key;
    };

    return (
        <LanguageContext.Provider value={{ lang, setLang, t }}>
            {children}
        </LanguageContext.Provider>
    );
}

export function useLanguage() {
    const context = useContext(LanguageContext);
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider');
    }
    return context;
}
