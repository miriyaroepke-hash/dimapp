"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { CheckCircle } from "lucide-react";
import { Suspense } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

function SuccessContent() {
    const { t } = useLanguage();
    const searchParams = useSearchParams();
    const orderNumber = searchParams.get("orderNumber");
    const payment = searchParams.get("payment");
    const total = searchParams.get("total");

    return (
        <main className="container animate-fade-in" style={{ padding: '8rem 2rem', minHeight: '80vh', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <CheckCircle size={80} color="#008160" style={{ marginBottom: '2rem' }} />
            <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '1rem' }}>{t('success_thanks')}</h1>
            <p style={{ fontSize: '1.2rem', opacity: 0.8, marginBottom: '2rem', maxWidth: '600px', lineHeight: 1.5 }}>
                Ваш заказ <strong>{orderNumber}</strong> {t('success_wait')}
            </p>

            <div style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)', borderRadius: '12px', padding: '2rem', width: '100%', maxWidth: '500px', textAlign: 'left', marginBottom: '2rem' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '1rem' }}>{t('success_order_info')}</h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--card-border)' }}>
                    <span>{t('success_amount')}</span>
                    <span style={{ fontWeight: 800, fontSize: '1.25rem' }}>{Number(total || 0).toLocaleString()} ₸</span>
                </div>
                
                {payment === 'KASPI' && (
                    <div style={{ marginTop: '1rem' }}>
                        <p style={{ marginBottom: '1rem', lineHeight: 1.5 }}>
                            Выбранный способ оплаты: <strong>Каспи Банк</strong>
                        </p>
                        <a
                            href={`https://pay.kaspi.kz/pay/g92ugs1n?Amount=${Math.round(Number(total || 0))}&Comment=${encodeURIComponent('Заказ ' + orderNumber)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '0.75rem',
                                padding: '1rem 1.5rem',
                                backgroundColor: '#F14635',
                                color: 'white',
                                borderRadius: '12px',
                                fontWeight: 700,
                                fontSize: '1.1rem',
                                textDecoration: 'none',
                                boxShadow: '0 4px 16px rgba(241,70,53,0.3)',
                                transition: 'transform 0.15s',
                            }}
                        >
                            💳 Оплатить через Kaspi — {Number(total || 0).toLocaleString()} ₸
                        </a>
                        <p style={{ fontSize: '0.85rem', opacity: 0.6, marginTop: '0.75rem', textAlign: 'center' }}>
                            После оплаты статус заказа обновится автоматически
                        </p>
                    </div>
                )}

                {payment === 'HALYK' && (
                    <div style={{ marginTop: '1rem' }}>
                        <p style={{ marginBottom: '1rem', lineHeight: 1.5 }}>
                            {t('success_chosen_payment')} <strong>{t('halyk_bank_title')}</strong>
                        </p>
                        <p style={{ fontSize: '0.95rem', opacity: 0.8, lineHeight: 1.5 }}>
                            {t('success_halyk_msg')}
                        </p>
                    </div>
                )}
            </div>

            <div style={{ display: 'flex', gap: '1rem' }}>
                <Link 
                    href="https://api.whatsapp.com/send/?phone=77477677124&text=Здравствуйте! Я оформил(а) заказ на сайте: " 
                    target="_blank"
                    style={{
                        padding: '1rem 2rem',
                        backgroundColor: '#25D366',
                        color: 'white',
                        fontWeight: 600,
                        borderRadius: '8px',
                        textDecoration: 'none'
                    }}
                >
                    {t('success_whatsapp')}
                </Link>
                <Link 
                    href="/products" 
                    style={{
                        padding: '1rem 2rem',
                        backgroundColor: 'transparent',
                        border: '1px solid var(--card-border)',
                        color: 'var(--foreground)',
                        fontWeight: 600,
                        borderRadius: '8px',
                        textDecoration: 'none'
                    }}
                >
                    {t('continue_shopping')}
                </Link>
            </div>
        </main>
    );
}

export default function SuccessPage() {
    return (
        <Suspense fallback={<div style={{ padding: '8rem', textAlign: 'center' }}>Загрузка...</div>}>
            <SuccessContent />
        </Suspense>
    );
}
