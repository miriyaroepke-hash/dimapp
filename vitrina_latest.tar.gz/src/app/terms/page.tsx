"use client";

import { useLanguage } from "@/contexts/LanguageContext";

export default function TermsPage() {
    const { t } = useLanguage();

    return (
        <main className="container" style={{ padding: '8rem 2rem', minHeight: '60vh' }}>
            <h1 style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '2rem' }}>{t('nav_terms')}</h1>
            <p style={{ opacity: 0.7, fontSize: '1.2rem' }}>{t('section_in_development')}</p>
        </main>
    );
}
