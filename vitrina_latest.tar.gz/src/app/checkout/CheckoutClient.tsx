'use client';

import { useCartStore } from "@/store/useCartStore";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useLanguage } from "@/contexts/LanguageContext";

export default function CheckoutClient({ session }: { session: any }) {
    const { items, clearCart } = useCartStore();
    const router = useRouter();
    const { t } = useLanguage();

    const [mounted, setMounted] = useState(false);
    
    // Form standard state
    const [name, setName] = useState(session?.user?.name || '');
    const [phone, setPhone] = useState(session?.user?.phone || '');
    const [city, setCity] = useState('');
    const [street, setStreet] = useState('');
    const [house, setHouse] = useState('');
    const [apartment, setApartment] = useState('');
    const [comment, setComment] = useState('');
    
    // Form selections
    const [deliveryMethod, setDeliveryMethod] = useState(''); // PICKUP, YANDEX, KAZPOST, CDEK_COURIER, CDEK_PVZ
    const [paymentMethod, setPaymentMethod] = useState('KASPI'); 
    
    // Delivery calculations
    const [confirmedCity, setConfirmedCity] = useState('');
    const [isCalculating, setIsCalculating] = useState(false);
    const [calcError, setCalcError] = useState('');
    const [cdekCourierPrice, setCdekCourierPrice] = useState<number | null>(null);
    const [cdekCourierPeriod, setCdekCourierPeriod] = useState<string>('');
    const [cdekPvzPrice, setCdekPvzPrice] = useState<number | null>(null);
    const [cdekPvzPeriod, setCdekPvzPeriod] = useState<string>('');
    const [pvzList, setPvzList] = useState<any[]>([]);
    const [selectedPvz, setSelectedPvz] = useState('');

    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) return null;

    if (items.length === 0) {
        return (
            <main className="container" style={{ padding: '8rem 2rem', minHeight: '60vh', textAlign: 'center' }}>
                <h2>{t('cart_empty')}</h2>
                <button onClick={() => router.push('/products')} style={{ marginTop: '1rem', padding: '0.8rem 1.5rem', cursor: 'pointer' }}>
                    {t('continue_shopping')}
                </button>
            </main>
        );
    }

    const totalQuantity = items.reduce((acc, item) => acc + item.quantity, 0);
    const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
    
    let deliveryCost = 0;
    if (deliveryMethod === 'KAZPOST') deliveryCost = 1400;
    else if (deliveryMethod === 'CDEK_COURIER') deliveryCost = cdekCourierPrice || 0;
    else if (deliveryMethod === 'CDEK_PVZ') deliveryCost = cdekPvzPrice || 0;
    // PICKUP / YANDEX are 0 (Yandex is paid on delivery)

    const total = subtotal + deliveryCost;

    const isAlmaty = confirmedCity.trim().toLowerCase() === 'алматы';

    const getDeliveryOptions = async () => {
        if (!city) return;
        setIsCalculating(true);
        setCalcError('');
        setDeliveryMethod('');
        setCdekCourierPrice(null);
        setCdekCourierPeriod('');
        setCdekPvzPrice(null);
        setCdekPvzPeriod('');
        setPvzList([]);
        setConfirmedCity(city);

        try {
            const res = await fetch('/api/cdek/calculate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ city, quantity: totalQuantity })
            });
            const data = await res.json();
            
            if (!res.ok) throw new Error(data.error || 'Ошибка расчета');

            if (data.courierPrice) {
                setCdekCourierPrice(data.courierPrice);
                setCdekCourierPeriod(data.courierPeriod || '');
            }
            if (data.pvzPrice) {
                setCdekPvzPrice(data.pvzPrice);
                setCdekPvzPeriod(data.pvzPeriod || '');
            }

            if (data.cityCode) {
                const pvzRes = await fetch(`/api/cdek/pvz?cityCode=${data.cityCode}`);
                if (pvzRes.ok) {
                    const pvzData = await pvzRes.json();
                    setPvzList(pvzData);
                    if (pvzData.length > 0) setSelectedPvz(pvzData[0].location.address);
                }
            }
            
        } catch (error: any) {
            setCalcError(error.message);
        } finally {
            setIsCalculating(false);
        }
    };

    const submitOrder = async () => {
        if (!name || !phone || !confirmedCity || !deliveryMethod) {
            alert('Заполните все обязательные поля');
            return;
        }

        if (deliveryMethod === 'CDEK_PVZ' && !selectedPvz) {
            alert('Выберите пункт выдачи СДЭК');
            return;
        }

        setIsSubmitting(true);
        try {
            const finalAddress = deliveryMethod === 'CDEK_PVZ' 
                ? `Пункт выдачи СДЭК: ${selectedPvz}` 
                : `${street} ${house} ${apartment}`.trim();

            const orderPayload = {
                clientName: name,
                clientPhone: phone,
                city: confirmedCity,
                street: deliveryMethod === 'CDEK_PVZ' ? '' : street,
                house: deliveryMethod === 'CDEK_PVZ' ? '' : house,
                apartment: deliveryMethod === 'CDEK_PVZ' ? '' : apartment,
                comment: `Доставка: ${deliveryMethod}. ${comment}`,
                paymentMethod,
                deliveryCost,
                totalAmount: total,
                customerId: session?.user?.id,
                items: items.map(i => ({
                    productId: i.productId,
                    name: i.name,
                    sku: i.kaspiSku || 'SKU',
                    size: i.size,
                    image: i.image,
                    quantity: i.quantity,
                    price: i.price
                }))
            };

            const res = await fetch('/api/orders/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderPayload)
            });

            if (!res.ok) {
                throw new Error('Ошибка при создании заказа');
            }

            const data = await res.json();
            
            clearCart();

            // Kaspi Bank payment — redirect directly to Kaspi Pay with pre-filled amount
            if (paymentMethod === 'KASPI') {
                const kaspiPayUrl = `https://pay.kaspi.kz/pay/g92ugs1n?Amount=${Math.round(total)}&Comment=${encodeURIComponent('\u0417\u0430\u043a\u0430\u0437 ' + data.orderNumber)}`;
                window.location.href = kaspiPayUrl;
                return;
            }

            router.push(`/checkout/success?orderNumber=${data.orderNumber}&payment=${paymentMethod}&total=${total}`);

        } catch (err: any) {
            alert(err.message);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <main className="container" style={{ padding: '6rem 2rem', minHeight: '80vh' }}>
            <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '3rem' }}>{t('checkout_title')}</h1>

            <div style={{ display: 'flex', gap: '4rem', flexWrap: 'wrap' }}>
                
                <div style={{ flex: '1 1 500px', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                    
                    <section>
                        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1rem', borderBottom: '1px solid #ddd', paddingBottom: '0.5rem' }}>{t('checkout_contacts')}</h2>
                        <div style={{ display: 'grid', gap: '1rem' }}>
                            <input type="text" placeholder={t('checkout_name')} value={name} onChange={e => setName(e.target.value)} style={inputStyle} />
                            <input type="text" placeholder="+7 (707) 000-00-00 *" value={phone} onChange={e => setPhone(e.target.value)} style={inputStyle} />
                        </div>
                    </section>

                    <section>
                        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1rem', borderBottom: '1px solid #ddd', paddingBottom: '0.5rem' }}>{t('checkout_city_title')}</h2>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <input type="text" placeholder={t('checkout_city_placeholder')} value={city} onChange={e => setCity(e.target.value)} style={{...inputStyle, flex: 1}} />
                            <button onClick={getDeliveryOptions} disabled={!city || isCalculating} style={{ padding: '0 1rem', cursor: 'pointer', backgroundColor: 'var(--foreground)', color: 'var(--background)', border: 'none', borderRadius: '8px', fontWeight: 600 }}>
                                {isCalculating ? t('cdek_loading') : t('checkout_city_btn')}
                            </button>
                        </div>
                        {calcError && <p style={{ color: 'red', fontSize: '0.85rem', margin: '0.5rem 0 0 0' }}>{calcError}</p>}
                    </section>

                    {confirmedCity && (
                        <section className="animate-fade-in" style={{ padding: '1.5rem', backgroundColor: '#f9f9f9', borderRadius: '12px', border: '1px solid #eaeaea' }}>
                            <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '1rem' }}>{t('checkout_delivery_title')} {confirmedCity}</h2>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                                
                                {isAlmaty && (
                                    <>
                                        <label style={radioContainerStyle(deliveryMethod, 'PICKUP')}>
                                            <input type="radio" value="PICKUP" checked={deliveryMethod === 'PICKUP'} onChange={() => setDeliveryMethod('PICKUP')} style={{ display: 'none' }} />
                                            <div>
                                                <div style={{ fontWeight: 600 }}>{t('pickup_title')}</div>
                                                <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>{t('pickup_desc')}</div>
                                            </div>
                                        </label>
                                        <label style={radioContainerStyle(deliveryMethod, 'YANDEX')}>
                                            <input type="radio" value="YANDEX" checked={deliveryMethod === 'YANDEX'} onChange={() => setDeliveryMethod('YANDEX')} style={{ display: 'none' }} />
                                            <div>
                                                <div style={{ fontWeight: 600 }}>{t('yandex_title')}</div>
                                                <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>{t('yandex_desc')}</div>
                                            </div>
                                        </label>
                                    </>
                                )}

                                {!isAlmaty && (
                                    <label style={radioContainerStyle(deliveryMethod, 'KAZPOST')}>
                                        <input type="radio" value="KAZPOST" checked={deliveryMethod === 'KAZPOST'} onChange={() => setDeliveryMethod('KAZPOST')} style={{ display: 'none' }} />
                                        <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                                            <div>
                                                <div style={{ fontWeight: 600 }}>{t('kazpost_title')}</div>
                                                <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>{t('kazpost_desc')}</div>
                                            </div>
                                            <div style={{ fontWeight: 700 }}>1 400 ₸</div>
                                        </div>
                                    </label>
                                )}

                                {cdekCourierPrice !== null && (
                                    <label style={radioContainerStyle(deliveryMethod, 'CDEK_COURIER')}>
                                        <input type="radio" value="CDEK_COURIER" checked={deliveryMethod === 'CDEK_COURIER'} onChange={() => setDeliveryMethod('CDEK_COURIER')} style={{ display: 'none' }} />
                                        <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                                            <div>
                                                <div style={{ fontWeight: 600 }}>{t('cdek_courier_title')}</div>
                                                {cdekCourierPeriod && <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>{t('cdek_est')} {cdekCourierPeriod}</div>}
                                            </div>
                                            <div style={{ fontWeight: 700 }}>{cdekCourierPrice} ₸</div>
                                        </div>
                                    </label>
                                )}

                                {cdekPvzPrice !== null && (
                                    <label style={{ ...radioContainerStyle(deliveryMethod, 'CDEK_PVZ'), flexDirection: 'column', alignItems: 'flex-start' }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                                            <input type="radio" value="CDEK_PVZ" checked={deliveryMethod === 'CDEK_PVZ'} onChange={() => setDeliveryMethod('CDEK_PVZ')} style={{ display: 'none' }} />
                                            <div>
                                                <div style={{ fontWeight: 600 }}>{t('cdek_pvz_title')}</div>
                                                {cdekPvzPeriod && <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>{t('cdek_est')} {cdekPvzPeriod}</div>}
                                            </div>
                                            <div style={{ fontWeight: 700 }}>{cdekPvzPrice} ₸</div>
                                        </div>
                                        {deliveryMethod === 'CDEK_PVZ' && pvzList.length > 0 && (
                                            <div style={{ marginTop: '1rem', width: '100%' }}>
                                                <select 
                                                    value={selectedPvz} 
                                                    onChange={e => setSelectedPvz(e.target.value)} 
                                                    style={{...inputStyle, padding: '0.5rem', fontSize: '0.9rem'}}
                                                >
                                                    {pvzList.map(pvz => (
                                                        <option key={pvz.code} value={pvz.location.address}>
                                                            {pvz.location.address}
                                                        </option>
                                                    ))}
                                                </select>
                                                <p style={{ fontSize: '0.75rem', marginTop: '0.5rem', opacity: 0.7 }}>{t('cdek_pvz_note')}</p>
                                            </div>
                                        )}
                                    </label>
                                )}
                            </div>
                        </section>
                    )}

                    {deliveryMethod && deliveryMethod !== 'PICKUP' && deliveryMethod !== 'CDEK_PVZ' && (
                        <section className="animate-fade-in">
                            <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '1rem' }}>{t('checkout_address_title')}</h2>
                            <div style={{ display: 'grid', gap: '1rem' }}>
                                <input type="text" placeholder={t('checkout_street')} value={street} onChange={e => setStreet(e.target.value)} style={inputStyle} />
                                <div style={{ display: 'flex', gap: '1rem' }}>
                                    <input type="text" placeholder={t('checkout_house')} value={house} onChange={e => setHouse(e.target.value)} style={inputStyle} />
                                    <input type="text" placeholder={t('checkout_apt')} value={apartment} onChange={e => setApartment(e.target.value)} style={inputStyle} />
                                </div>
                            </div>
                        </section>
                    )}

                    {deliveryMethod && (
                        <section className="animate-fade-in">
                            <textarea placeholder={t('checkout_comment')} value={comment} onChange={e => setComment(e.target.value)} style={{...inputStyle, minHeight: '80px', resize: 'vertical'}} />
                        </section>
                    )}

                    <section>
                        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '1rem', borderBottom: '1px solid #ddd', paddingBottom: '0.5rem' }}>{t('checkout_payment_title')}</h2>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                            <label style={radioContainerStyle(paymentMethod, 'KASPI')}>
                                <input type="radio" value="KASPI" checked={paymentMethod === 'KASPI'} onChange={() => setPaymentMethod('KASPI')} style={{ display: 'none' }} />
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                    <div style={{ width: '20px', height: '20px', borderRadius: '50%', backgroundColor: paymentMethod === 'KASPI' ? '#F14635' : '#ddd', display: 'inline-block' }}></div>
                                    <div style={{ fontWeight: 600 }}>{t('kaspi_bank_title')}</div>
                                </div>
                            </label>
                            <label style={radioContainerStyle(paymentMethod, 'HALYK')}>
                                <input type="radio" value="HALYK" checked={paymentMethod === 'HALYK'} onChange={() => setPaymentMethod('HALYK')} style={{ display: 'none' }} />
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                    <div style={{ width: '20px', height: '20px', borderRadius: '50%', backgroundColor: paymentMethod === 'HALYK' ? '#008160' : '#ddd', display: 'inline-block' }}></div>
                                    <div style={{ fontWeight: 600 }}>{t('halyk_bank_title')}</div>
                                </div>
                            </label>
                        </div>
                    </section>
                </div>

                {/* Summary Section */}
                <div style={{ flex: '1 1 350px' }}>
                    <div style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)', borderRadius: '12px', padding: '2rem', position: 'sticky', top: '100px' }}>
                        <h3 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '1.5rem' }}>{t('checkout_order')}</h3>
                        
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
                            {items.map(item => (
                                <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.95rem' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                                        {item.image && <img src={item.image} alt="pic" style={{ width: '40px', height: '50px', objectFit: 'cover', borderRadius: '4px' }} />}
                                        <div>
                                            <span style={{ fontWeight: 600 }}>{item.name}</span>
                                            <div style={{ opacity: 0.6, fontSize: '0.8rem' }}>{t('size')}: {item.size || 'Уни'} x {item.quantity}</div>
                                        </div>
                                    </div>
                                    <span style={{ fontWeight: 500 }}>{(item.price * item.quantity).toLocaleString()} ₸</span>
                                </div>
                            ))}
                        </div>

                        <div style={{ padding: '1.5rem 0', borderTop: '1px solid var(--card-border)', borderBottom: '1px solid var(--card-border)', marginBottom: '1.5rem' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', opacity: 0.8 }}>
                                <span>{t('checkout_products')} ({totalQuantity}):</span>
                                <span>{subtotal.toLocaleString()} ₸</span>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', opacity: 0.8 }}>
                                <span>{t('checkout_delivery_cost')}</span>
                                <span>{deliveryCost > 0 ? `${deliveryCost.toLocaleString()} ₸` : (deliveryMethod ? '0 ₸' : '—')}</span>
                            </div>
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                            <span style={{ fontSize: '1.2rem', fontWeight: 800 }}>{t('checkout_total')}</span>
                            <span style={{ fontSize: '1.5rem', fontWeight: 800 }}>{total.toLocaleString()} ₸</span>
                        </div>

                        <button 
                            onClick={submitOrder}
                            disabled={isSubmitting || !deliveryMethod}
                            style={{
                                width: '100%',
                                padding: '1rem',
                                backgroundColor: 'var(--foreground)',
                                color: 'var(--background)',
                                border: 'none',
                                borderRadius: '8px',
                                fontSize: '1.1rem',
                                fontWeight: 700,
                                cursor: isSubmitting || !deliveryMethod ? 'not-allowed' : 'pointer',
                                opacity: isSubmitting || !deliveryMethod ? 0.5 : 1
                            }}
                        >
                            {isSubmitting ? t('checkout_submitting') : t('checkout_submit')}
                        </button>
                        {!deliveryMethod && (
                            <p style={{ textAlign: 'center', marginTop: '0.5rem', fontSize: '0.75rem', color: '#ff3b30' }}>{t('checkout_btn_disabled')}</p>
                        )}
                    </div>
                </div>

            </div>
        </main>
    );
}

const inputStyle = {
    padding: '0.8rem 1rem',
    borderRadius: '8px',
    border: '1px solid #ddd',
    backgroundColor: '#fff',
    fontSize: '1rem',
    fontFamily: 'inherit',
    width: '100%'
};

const radioContainerStyle = (currentVal: string, val: string) => ({
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    cursor: 'pointer',
    padding: '1rem',
    border: currentVal === val ? '2px solid var(--foreground)' : '1px solid #ddd',
    borderRadius: '8px',
    backgroundColor: currentVal === val ? 'rgba(0,0,0,0.02)' : 'transparent',
    transition: 'all 0.2s',
    width: '100%'
});
