import { NextRequest, NextResponse } from 'next/server';
import { v2 as cloudinary } from 'cloudinary';
import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });


export async function POST(req: NextRequest) {
    // Configure fresh on each request to avoid module-level caching issues
    cloudinary.config({
        cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
        api_key: process.env.CLOUDINARY_API_KEY,
        api_secret: process.env.CLOUDINARY_API_SECRET,
    });
    try {
        const formData = await req.formData();
        const file = formData.get('image') as File | null;
        const productIdStr = formData.get('productId') as string | null;

        if (!file || !productIdStr) {
            return NextResponse.json({ error: 'Missing image or product ID' }, { status: 400 });
        }

        const productId = parseInt(productIdStr, 10);

        const buffer = await file.arrayBuffer();
        const base64Image = Buffer.from(buffer).toString('base64');
        const dataUri = `data:${file.type};base64,${base64Image}`;

        // Upload to Cloudinary
        const result = await cloudinary.uploader.upload(dataUri, {
            folder: 'inventory_showcase',
        });

        // Update Product in Prisma
        const updatedProduct = await prisma.product.update({
            where: { id: productId },
            data: { image: result.secure_url },
        });

        return NextResponse.json({ success: true, product: updatedProduct });
    } catch (error) {
        console.error('Upload error:', error);
        return NextResponse.json({ error: 'Failed to upload image' }, { status: 500 });
    }
}
