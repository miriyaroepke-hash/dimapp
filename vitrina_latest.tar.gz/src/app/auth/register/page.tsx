"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export default function RegisterPage() {
    const { t } = useLanguage();
    const router = useRouter();
    const [phone, setPhone] = useState("");
    const [password, setPassword] = useState("");
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [error, setError] = useState("");
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError("");
        setIsLoading(true);

        try {
            const res = await fetch("/api/auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ phone, password, firstName, lastName }),
            });

            const data = await res.json();

            if (!res.ok) {
                setError(data.error || "Ошибка регистрации");
                setIsLoading(false);
                return;
            }

            // Immediately sign them in
            const authRes = await signIn("credentials", {
                phone,
                password,
                redirect: false,
            });

            if (authRes?.error) {
                setError("Аккаунт создан, но войти не удалось. Пожалуйста, войдите вручную.");
                setIsLoading(false);
            } else {
                router.push("/profile");
                router.refresh();
            }
        } catch (error) {
            setError("Произошла ошибка сети");
            setIsLoading(false);
        }
    };

    return (
        <div style={{ display: 'flex', minHeight: '80vh', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
            <div style={{
                width: '100%',
                maxWidth: '430px',
                backgroundColor: 'var(--card-bg)',
                borderRadius: 'var(--radius)',
                padding: '2.5rem',
                border: '1px solid var(--card-border)',
                boxShadow: '0 10px 30px rgba(0,0,0,0.02)',
                animation: 'fadeIn 0.6s ease-out forwards',
            }}>
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <h1 style={{ fontSize: '1.8rem', fontWeight: 700, marginBottom: '0.5rem', color: 'var(--foreground)' }}>
                        {t('register_title')}
                    </h1>
                    <p style={{ color: 'var(--foreground)', opacity: 0.6, fontSize: '0.95rem' }}>
                        {t('register_sub')}
                    </p>
                </div>

                {error && (
                    <div style={{
                        padding: '1rem',
                        backgroundColor: '#FEF2F2',
                        color: '#991B1B',
                        borderRadius: '8px',
                        fontSize: '0.9rem',
                        marginBottom: '1.5rem',
                        border: '1px solid #FEE2E2',
                    }}>
                        {error}
                    </div>
                )}

                <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        <div>
                            <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.9rem', fontWeight: 500, opacity: 0.8 }} htmlFor="firstName">
                                {t('first_name')}
                            </label>
                            <input
                                id="firstName"
                                type="text"
                                placeholder={t('aliya')}
                                value={firstName}
                                onChange={(e) => setFirstName(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '0.8rem 1rem',
                                    borderRadius: '8px',
                                    border: '1px solid var(--card-border)',
                                    fontSize: '1rem',
                                    outline: 'none',
                                    background: 'transparent',
                                    color: 'var(--foreground)',
                                    transition: 'border-color 0.2s',
                                }}
                                onFocus={e => (e.target.style.borderColor = 'var(--primary)')}
                                onBlur={e => (e.target.style.borderColor = 'var(--card-border)')}
                            />
                        </div>
                        <div>
                            <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.9rem', fontWeight: 500, opacity: 0.8 }} htmlFor="lastName">
                                {t('last_name')}
                            </label>
                            <input
                                id="lastName"
                                type="text"
                                placeholder={t('akhmetova')}
                                value={lastName}
                                onChange={(e) => setLastName(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '0.8rem 1rem',
                                    borderRadius: '8px',
                                    border: '1px solid var(--card-border)',
                                    fontSize: '1rem',
                                    outline: 'none',
                                    background: 'transparent',
                                    color: 'var(--foreground)',
                                    transition: 'border-color 0.2s',
                                }}
                                onFocus={e => (e.target.style.borderColor = 'var(--primary)')}
                                onBlur={e => (e.target.style.borderColor = 'var(--card-border)')}
                            />
                        </div>
                    </div>

                    <div>
                        <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.9rem', fontWeight: 500, opacity: 0.8 }} htmlFor="phone">
                            {t('phone_req')}
                        </label>
                        <input
                            id="phone"
                            type="tel"
                            required
                            placeholder="+7(777)77-77-777"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            style={{
                                width: '100%',
                                padding: '0.8rem 1rem',
                                borderRadius: '8px',
                                border: '1px solid var(--card-border)',
                                fontSize: '1rem',
                                outline: 'none',
                                background: 'transparent',
                                color: 'var(--foreground)',
                                transition: 'border-color 0.2s',
                            }}
                            onFocus={e => (e.target.style.borderColor = 'var(--primary)')}
                            onBlur={e => (e.target.style.borderColor = 'var(--card-border)')}
                        />
                    </div>

                    <div>
                        <label style={{ display: 'block', marginBottom: '0.4rem', fontSize: '0.9rem', fontWeight: 500, opacity: 0.8 }} htmlFor="password">
                            {t('pwd_req')}
                        </label>
                        <input
                            id="password"
                            type="password"
                            required
                            minLength={6}
                            placeholder={t('pwd_min')}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            style={{
                                width: '100%',
                                padding: '0.8rem 1rem',
                                borderRadius: '8px',
                                border: '1px solid var(--card-border)',
                                fontSize: '1rem',
                                outline: 'none',
                                background: 'transparent',
                                color: 'var(--foreground)',
                                transition: 'border-color 0.2s',
                            }}
                            onFocus={e => (e.target.style.borderColor = 'var(--primary)')}
                            onBlur={e => (e.target.style.borderColor = 'var(--card-border)')}
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={isLoading || !phone || !password || password.length < 6}
                        style={{
                            marginTop: '0.5rem',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '0.5rem',
                            width: '100%',
                            padding: '1rem',
                            backgroundColor: 'var(--primary)',
                            color: 'var(--primary-foreground)',
                            border: 'none',
                            borderRadius: '8px',
                            fontWeight: 600,
                            fontSize: '1rem',
                            cursor: (isLoading || !phone || !password || password.length < 6) ? 'not-allowed' : 'pointer',
                            opacity: (isLoading || !phone || !password || password.length < 6) ? 0.7 : 1,
                            transition: 'opacity 0.2s',
                        }}
                    >
                        {isLoading ? <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }} /> : t('register_btn')}
                    </button>
                    <style dangerouslySetInnerHTML={{ __html: `@keyframes spin { 100% { transform: rotate(360deg); } }` }} />
                </form>

                <div style={{ marginTop: '2rem', paddingTop: '1.5rem', borderTop: '1px solid var(--card-border)', textAlign: 'center' }}>
                    <p style={{ fontSize: '0.95rem', opacity: 0.7 }}>
                        {t('have_account')} {" "}
                        <Link href="/auth/login" style={{ fontWeight: 600, color: 'var(--primary)', textDecoration: 'underline' }}>
                            {t('login')}
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
}
