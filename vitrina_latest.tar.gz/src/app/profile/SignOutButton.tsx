"use client";

import { signOut } from "next-auth/react";
import { LogOut } from "lucide-react";

export default function SignOutButton() {
    return (
        <button 
            onClick={() => signOut({ callbackUrl: "/" })}
            style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.4rem',
                padding: '0.5rem 1rem',
                backgroundColor: 'transparent',
                border: '1px solid var(--card-border)',
                borderRadius: '8px',
                fontSize: '0.9rem',
                fontWeight: 500,
                color: 'var(--foreground)',
                cursor: 'pointer',
                transition: 'all 0.2s',
            }}
            onMouseOver={e => {
                e.currentTarget.style.backgroundColor = '#FEF2F2';
                e.currentTarget.style.borderColor = '#FECACA';
                e.currentTarget.style.color = '#DC2626';
            }}
            onMouseOut={e => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.borderColor = 'var(--card-border)';
                e.currentTarget.style.color = 'var(--foreground)';
            }}
        >
            <LogOut size={16} />
            Выйти
        </button>
    );
}
