import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { phone, password, firstName, lastName } = body;

        if (!phone || !password) {
            return NextResponse.json({ error: "Телефон и пароль обязательны" }, { status: 400 });
        }

        // Check if user exists
        const existingUser = await prisma.customer.findUnique({
            where: { phone },
        });

        if (existingUser) {
            return NextResponse.json({ error: "Пользователь с таким номером уже существует" }, { status: 400 });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newCustomer = await prisma.customer.create({
            data: {
                phone,
                password: hashedPassword,
                firstName,
                lastName,
            },
        });

        // Don't return the password
        const { password: _, ...customerWithoutPassword } = newCustomer;

        return NextResponse.json({ message: "Регистрация успешна", user: customerWithoutPassword }, { status: 201 });
    } catch (error: any) {
        console.error("Ошибка при регистрации:", error);
        return NextResponse.json({ error: "Внутренняя ошибка сервера" }, { status: 500 });
    }
}
