'use client';

import { useLanguage } from '@/contexts/LanguageContext';

import ReactMarkdown from 'react-markdown';

export default function ContactsClient({ content }: { content: any }) {
    const { lang, t } = useLanguage();

    const contactsText = lang === 'RU'
        ? (content?.contacts_ru || 'Контактная информация скоро появится...')
        : (content?.contacts_kz || 'Байланыс ақпараты жақында шығады...');

    return (
        <main className="container animate-fade-in" style={{ padding: '4rem 2rem', paddingTop: '8rem' }}>
            <div style={{ maxWidth: '800px', margin: '0 auto' }}>
                <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '2rem' }}>
                    {t('nav_contacts')}
                </h1>
                <div style={{
                    fontSize: '1.25rem',
                    lineHeight: 1.8,
                    color: 'var(--foreground)',
                    opacity: 0.9,
                }}>
                    <ReactMarkdown 
                        components={{
                            strong: ({node, ...props}) => <strong style={{ fontWeight: 700 }} {...props} />,
                            h1: ({node, ...props}) => <h1 style={{ fontSize: '2rem', fontWeight: 800, margin: '2rem 0 1rem' }} {...props} />,
                            h2: ({node, ...props}) => <h2 style={{ fontSize: '1.75rem', fontWeight: 700, margin: '1.5rem 0 1rem' }} {...props} />,
                            h3: ({node, ...props}) => <h3 style={{ fontSize: '1.5rem', fontWeight: 700, margin: '1.5rem 0 1rem' }} {...props} />,
                            p: ({node, ...props}) => <p style={{ marginBottom: '1rem' }} {...props} />,
                            ul: ({node, ...props}) => <ul style={{ marginBottom: '1rem', paddingLeft: '1.5rem', listStyleType: 'disc' }} {...props} />,
                            ol: ({node, ...props}) => <ol style={{ marginBottom: '1rem', paddingLeft: '1.5rem', listStyleType: 'decimal' }} {...props} />,
                            li: ({node, ...props}) => <li style={{ marginBottom: '0.5rem' }} {...props} />,
                            hr: ({node, ...props}) => <hr style={{ margin: '2rem 0', opacity: 0.2 }} {...props} />,
                        }}
                    >
                        {contactsText}
                    </ReactMarkdown>
                </div>
            </div>
        </main>
    );
}
