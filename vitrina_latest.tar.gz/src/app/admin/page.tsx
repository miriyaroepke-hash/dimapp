'use client';
import { useState, useEffect } from 'react';

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────
interface StorefrontProduct {
    id: number;
    name: string;
    description?: string | null;
    image?: string | null;
    images: string[];
    discountPrice?: number | null;
    isActive: boolean;
    products: { id: number; name: string; size?: string | null; price: number; sku: string }[];
}

// ──────────────────────────────────────────────
// Main Component
// ──────────────────────────────────────────────
export default function AdminPage() {
    const [siteContent, setSiteContent] = useState<any>({});
    const [storefrontProducts, setStorefrontProducts] = useState<StorefrontProduct[]>([]);
    const [loading, setLoading] = useState(true);
    const [uploadingId, setUploadingId] = useState<number | string | null>(null);
    const [savingText, setSavingText] = useState(false);
    const [savingProduct, setSavingProduct] = useState<number | null>(null);
    const [editingProduct, setEditingProduct] = useState<{ [id: number]: Partial<StorefrontProduct> }>({});
    const [activeTab, setActiveTab] = useState<'site' | 'products'>('site');

    // Basic Auth State
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [passwordInput, setPasswordInput] = useState('');

    useEffect(() => {
        Promise.all([
            fetch('/api/content').then(res => res.json()),
            fetch('/api/storefront-products').then(res => res.json()),
        ])
            .then(([contentData, storefrontData]) => {
                setSiteContent(contentData);
                setStorefrontProducts(Array.isArray(storefrontData) ? storefrontData : []);
                setLoading(false);
            })
            .catch(err => { console.error(err); setLoading(false); });
    }, []);

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (passwordInput === 'admin123') {
            setIsAuthenticated(true);
            localStorage.setItem('dimmianiAdmin', 'true');
        } else {
            alert('Неверный пароль');
        }
    };

    // ── Save site text ──────────────────────────
    const handleTextSave = async () => {
        setSavingText(true);
        try {
            const res = await fetch('/api/content', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text_ru: siteContent.text_ru,
                    text_kz: siteContent.text_kz,
                    returns_ru: siteContent.returns_ru,
                    returns_kz: siteContent.returns_kz,
                    contacts_ru: siteContent.contacts_ru,
                    contacts_kz: siteContent.contacts_kz,
                })
            });
            if (res.ok) alert('Сохранено!');
            else alert('Ошибка при сохранении.');
        } catch (e) { alert('Ошибка.'); }
        finally { setSavingText(false); }
    };

    // ── Upload site media (videos/photos for homepage) ──
    const handleContentMediaUpload = async (e: React.ChangeEvent<HTMLInputElement>, fieldName: string) => {
        if (!e.target.files || e.target.files.length === 0) return;
        setUploadingId(fieldName);
        const formData = new FormData();
        formData.append('media', e.target.files[0]);
        formData.append('fieldName', fieldName);
        try {
            const res = await fetch('/api/content/upload', { method: 'POST', body: formData });
            if (res.ok) {
                const data = await res.json();
                setSiteContent({ ...siteContent, [fieldName]: data.url });
                alert('Загружено!');
            } else alert('Ошибка загрузки.');
        } catch (err) { alert('Ошибка.'); }
        finally { setUploadingId(null); }
    };

    // ── Save storefront product text fields ──────
    const handleProductSave = async (id: number) => {
        setSavingProduct(id);
        try {
            const edits = editingProduct[id] || {};
            const res = await fetch('/api/storefront-products', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, ...edits })
            });
            if (res.ok) {
                const { product } = await res.json();
                setStorefrontProducts(prev => prev.map(p => p.id === id ? product : p));
                setEditingProduct(prev => { const n = { ...prev }; delete n[id]; return n; });
                alert('Карточка сохранена!');
            } else alert('Ошибка сохранения карточки.');
        } catch (e) { alert('Ошибка.'); }
        finally { setSavingProduct(null); }
    };

    // ── Upload storefront product image ──────────
    const handleProductImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, productId: number, imageIndex: number) => {
        if (!e.target.files || e.target.files.length === 0) return;
        setUploadingId(`${productId}-${imageIndex}`);
        const formData = new FormData();
        formData.append('image', e.target.files[0]);
        formData.append('productId', productId.toString());
        formData.append('imageIndex', imageIndex.toString());
        try {
            const res = await fetch('/api/storefront-products', { method: 'POST', body: formData });
            if (res.ok) {
                const { product } = await res.json();
                setStorefrontProducts(prev => prev.map(p => p.id === productId ? product : p));
                alert('Фото загружено!');
            } else alert('Ошибка загрузки фото.');
        } catch (err) { alert('Ошибка.'); }
        finally { setUploadingId(null); }
    };

    const getProductEdit = (product: StorefrontProduct) => ({
        name: editingProduct[product.id]?.name ?? product.name,
        description: editingProduct[product.id]?.description ?? product.description ?? '',
        discountPrice: editingProduct[product.id]?.discountPrice ?? product.discountPrice ?? '',
        isActive: editingProduct[product.id]?.isActive ?? product.isActive,
    });

    const updateEdit = (id: number, field: string, value: any) => {
        setEditingProduct(prev => ({ ...prev, [id]: { ...prev[id], [field]: value } }));
    };

    // ──────────────────────────────────────────────
    // Styles
    // ──────────────────────────────────────────────
    const cardStyle: React.CSSProperties = {
        marginBottom: '2rem', padding: '2rem',
        background: 'var(--card-bg)', borderRadius: 'var(--radius)',
        border: '1px solid var(--card-border)'
    };
    const inputStyle: React.CSSProperties = {
        width: '100%', padding: '0.75rem', borderRadius: '8px',
        border: '1px solid var(--card-border)', fontSize: '0.95rem',
        boxSizing: 'border-box', background: 'var(--background)'
    };
    const btnPrimary: React.CSSProperties = {
        padding: '0.6rem 1.25rem', borderRadius: '8px',
        background: '#111', color: '#fff', fontWeight: 600,
        border: 'none', cursor: 'pointer', fontSize: '0.875rem'
    };
    const btnUpload: React.CSSProperties = {
        padding: '0.5rem 1rem', borderRadius: '8px',
        background: '#555', color: '#fff', fontWeight: 600,
        border: 'none', cursor: 'pointer', fontSize: '0.8rem',
        display: 'inline-block'
    };

    // ──────────────────────────────────────────────
    if (loading) return <div style={{ padding: '4rem 2rem', textAlign: 'center' }}>Загрузка...</div>;

    if (!isAuthenticated) {
        return (
            <div style={{ padding: '4rem 2rem', maxWidth: '400px', margin: '0 auto' }}>
                <h1 style={{ fontSize: '1.5rem', marginBottom: '1.5rem' }}>Вход в конструктор</h1>
                <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <input
                        type="password"
                        placeholder="Пароль"
                        value={passwordInput}
                        onChange={(e) => setPasswordInput(e.target.value)}
                        style={inputStyle}
                    />
                    <button type="submit" style={btnPrimary}>Войти</button>
                </form>
            </div>
        );
    }

    return (
        <div style={{ padding: '2rem', maxWidth: '960px', margin: '0 auto' }}>
            <h1 style={{ fontSize: '2rem', marginBottom: '1.5rem', fontWeight: 700 }}>Конструктор сайта</h1>

            {/* Tabs */}
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', borderBottom: '2px solid var(--card-border)' }}>
                {([['site', 'Контент сайта'], ['products', 'Карточки товаров']] as const).map(([tab, label]) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        style={{
                            padding: '0.75rem 1.5rem', fontWeight: 600, border: 'none',
                            borderBottom: activeTab === tab ? '3px solid #111' : '3px solid transparent',
                            background: 'none', cursor: 'pointer', fontSize: '1rem',
                            color: activeTab === tab ? '#111' : '#777'
                        }}
                    >{label}</button>
                ))}
            </div>

            {/* ══ TAB: SITE CONTENT ══════════════════════════════ */}
            {activeTab === 'site' && (
                <>
                    {/* Главная страница — текст */}
                    <section style={cardStyle}>
                        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', fontWeight: 600 }}>Главная страница — Текст</h2>
                        <div style={{ display: 'grid', gap: '1rem', marginBottom: '1rem' }}>
                            <label>
                                <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Заголовок (RU)</div>
                                <textarea
                                    value={siteContent.text_ru || ''}
                                    onChange={e => setSiteContent({ ...siteContent, text_ru: e.target.value })}
                                    style={{ ...inputStyle, minHeight: '80px' }}
                                />
                            </label>
                            <label>
                                <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Заголовок (KZ)</div>
                                <textarea
                                    value={siteContent.text_kz || ''}
                                    onChange={e => setSiteContent({ ...siteContent, text_kz: e.target.value })}
                                    style={{ ...inputStyle, minHeight: '80px' }}
                                />
                            </label>
                        </div>
                        <button onClick={handleTextSave} disabled={savingText} style={btnPrimary}>
                            {savingText ? 'Сохранение...' : 'Сохранить текст'}
                        </button>
                    </section>

                    {/* Главная страница — Фото */}
                    <section style={cardStyle}>
                        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', fontWeight: 600 }}>Главная страница — Фотографии</h2>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
                            {(['photo1', 'photo2'] as const).map((field, i) => (
                                <div key={field} style={{ border: '1px solid var(--card-border)', padding: '1rem', borderRadius: '8px' }}>
                                    <div style={{ fontWeight: 600, marginBottom: '0.75rem' }}>Фото {i + 1}</div>
                                    {siteContent[field] && (
                                        <img src={siteContent[field]} alt="" style={{ width: '100%', height: '180px', objectFit: 'cover', borderRadius: '6px', marginBottom: '0.75rem' }} />
                                    )}
                                    {!siteContent[field] && (
                                        <div style={{ width: '100%', height: '120px', background: '#f5f5f5', borderRadius: '6px', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#aaa', fontSize: '0.85rem' }}>
                                            Нет фото
                                        </div>
                                    )}
                                    <label style={btnUpload}>
                                        {uploadingId === field ? 'Загрузка...' : 'Загрузить фото'}
                                        <input type="file" accept="image/*" style={{ display: 'none' }}
                                            onChange={(e) => handleContentMediaUpload(e, field)}
                                            disabled={uploadingId !== null} />
                                    </label>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Видео */}
                    <section style={cardStyle}>
                        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', fontWeight: 600 }}>Главная страница — Видео</h2>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem' }}>
                            {(['video_url', 'video2_url', 'video3_url'] as const).map((field, i) => (
                                <div key={field} style={{ border: '1px solid var(--card-border)', padding: '1rem', borderRadius: '8px' }}>
                                    <div style={{ fontWeight: 600, marginBottom: '0.75rem' }}>Видео {i + 1}</div>
                                    {siteContent[field] ? (
                                        <video src={siteContent[field]} style={{ width: '100%', height: '140px', objectFit: 'cover', borderRadius: '6px', marginBottom: '0.75rem' }} muted />
                                    ) : (
                                        <div style={{ width: '100%', height: '100px', background: '#f5f5f5', borderRadius: '6px', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#aaa', fontSize: '0.85rem' }}>
                                            Нет видео
                                        </div>
                                    )}
                                    <label style={btnUpload}>
                                        {uploadingId === field ? 'Загрузка...' : 'Загрузить видео'}
                                        <input type="file" accept="video/*" style={{ display: 'none' }}
                                            onChange={(e) => handleContentMediaUpload(e, field)}
                                            disabled={uploadingId !== null} />
                                    </label>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Возвраты */}
                    <section style={cardStyle}>
                        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', fontWeight: 600 }}>Страница: Возвраты</h2>
                        <div style={{ display: 'grid', gap: '1rem', marginBottom: '1rem' }}>
                            <label>
                                <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Текст (RU)</div>
                                <textarea value={siteContent.returns_ru || ''} onChange={e => setSiteContent({ ...siteContent, returns_ru: e.target.value })} style={{ ...inputStyle, minHeight: '120px' }} />
                            </label>
                            <label>
                                <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Текст (KZ)</div>
                                <textarea value={siteContent.returns_kz || ''} onChange={e => setSiteContent({ ...siteContent, returns_kz: e.target.value })} style={{ ...inputStyle, minHeight: '120px' }} />
                            </label>
                        </div>
                        <button onClick={handleTextSave} disabled={savingText} style={btnPrimary}>
                            {savingText ? 'Сохранение...' : 'Сохранить'}
                        </button>
                    </section>

                    {/* Контакты */}
                    <section style={cardStyle}>
                        <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem', fontWeight: 600 }}>Страница: Контакты</h2>
                        <div style={{ display: 'grid', gap: '1rem', marginBottom: '1rem' }}>
                            <label>
                                <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Текст (RU)</div>
                                <textarea value={siteContent.contacts_ru || ''} onChange={e => setSiteContent({ ...siteContent, contacts_ru: e.target.value })} style={{ ...inputStyle, minHeight: '120px' }} />
                            </label>
                            <label>
                                <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Текст (KZ)</div>
                                <textarea value={siteContent.contacts_kz || ''} onChange={e => setSiteContent({ ...siteContent, contacts_kz: e.target.value })} style={{ ...inputStyle, minHeight: '120px' }} />
                            </label>
                        </div>
                        <button onClick={handleTextSave} disabled={savingText} style={btnPrimary}>
                            {savingText ? 'Сохранение...' : 'Сохранить'}
                        </button>
                    </section>
                </>
            )}

            {/* ══ TAB: STOREFRONT PRODUCTS ════════════════════════ */}
            {activeTab === 'products' && (
                <div>
                    <p style={{ color: '#666', marginBottom: '1.5rem', fontSize: '0.95rem' }}>
                        Здесь вы можете изменить название, описание, цену со скидкой и фотографии каждой карточки товара на витрине.
                    </p>
                    {storefrontProducts.length === 0 && (
                        <div style={{ textAlign: 'center', padding: '3rem', color: '#aaa' }}>
                            Нет товаров на витрине. Добавьте их через склад → Витрина.
                        </div>
                    )}
                    {storefrontProducts.map(product => {
                        const edit = getProductEdit(product);
                        const allImages = product.images?.length > 0
                            ? product.images
                            : product.image ? [product.image] : [];
                        // Always show up to 5 image slots
                        const imageSlots = Array.from({ length: 5 }, (_, i) => allImages[i] || null);

                        return (
                            <section key={product.id} style={cardStyle}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
                                    <div>
                                        <h2 style={{ fontSize: '1.2rem', fontWeight: 700 }}>{product.name}</h2>
                                        <p style={{ fontSize: '0.8rem', color: '#888', marginTop: '0.25rem' }}>
                                            Размеры: {product.products.map(p => p.size).filter(Boolean).join(', ') || 'Универсальный'}
                                        </p>
                                    </div>
                                    <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.875rem' }}>
                                        <input
                                            type="checkbox"
                                            checked={edit.isActive as boolean}
                                            onChange={e => updateEdit(product.id, 'isActive', e.target.checked)}
                                        />
                                        Показывать на сайте
                                    </label>
                                </div>

                                {/* Text Fields */}
                                <div style={{ display: 'grid', gap: '1rem', marginBottom: '1.5rem' }}>
                                    <label>
                                        <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Название карточки</div>
                                        <input
                                            type="text"
                                            value={edit.name as string}
                                            onChange={e => updateEdit(product.id, 'name', e.target.value)}
                                            style={inputStyle}
                                        />
                                    </label>
                                    <label>
                                        <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Описание (необязательно)</div>
                                        <textarea
                                            value={edit.description as string}
                                            onChange={e => updateEdit(product.id, 'description', e.target.value)}
                                            style={{ ...inputStyle, minHeight: '80px' }}
                                            placeholder="Краткое описание, видимое на карточке..."
                                        />
                                    </label>
                                    <label>
                                        <div style={{ fontWeight: 500, marginBottom: '0.4rem' }}>Цена со скидкой (₸) — оставьте пустым чтобы убрать</div>
                                        <input
                                            type="number"
                                            value={edit.discountPrice as string}
                                            onChange={e => updateEdit(product.id, 'discountPrice', e.target.value)}
                                            style={{ ...inputStyle, maxWidth: '250px' }}
                                            placeholder="Например: 9999"
                                        />
                                    </label>
                                </div>

                                <button
                                    onClick={() => handleProductSave(product.id)}
                                    disabled={savingProduct === product.id}
                                    style={{ ...btnPrimary, marginBottom: '1.5rem' }}
                                >
                                    {savingProduct === product.id ? 'Сохранение...' : 'Сохранить текст'}
                                </button>

                                {/* Photos */}
                                <div style={{ borderTop: '1px solid var(--card-border)', paddingTop: '1.5rem' }}>
                                    <div style={{ fontWeight: 600, marginBottom: '1rem' }}>Фотографии карточки (до 5 штук)</div>
                                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '1rem' }}>
                                        {imageSlots.map((url, idx) => (
                                            <div key={idx} style={{ border: '1px dashed var(--card-border)', borderRadius: '8px', padding: '0.75rem', textAlign: 'center' }}>
                                                <div style={{ fontSize: '0.75rem', color: '#888', marginBottom: '0.5rem' }}>Фото {idx + 1}</div>
                                                {url ? (
                                                    <img src={url} alt="" style={{ width: '100%', height: '120px', objectFit: 'cover', borderRadius: '6px', marginBottom: '0.5rem' }} />
                                                ) : (
                                                    <div style={{ width: '100%', height: '100px', background: '#f5f5f5', borderRadius: '6px', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#bbb', fontSize: '1.5rem' }}>+</div>
                                                )}
                                                <label style={{ ...btnUpload, width: '100%', textAlign: 'center', boxSizing: 'border-box' }}>
                                                    {uploadingId === `${product.id}-${idx}` ? 'Загрузка...' : url ? 'Заменить' : 'Добавить'}
                                                    <input type="file" accept="image/*" style={{ display: 'none' }}
                                                        onChange={(e) => handleProductImageUpload(e, product.id, idx)}
                                                        disabled={uploadingId !== null} />
                                                </label>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </section>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
