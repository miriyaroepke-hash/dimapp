import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL! });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

// Kaspi Pay sends a POST with payment result
// They include: txnId, amount, comment (which we set to "Заказ W-2026-XXXX")
export async function POST(req: NextRequest) {
    try {
        const body = await req.json().catch(() => null) || await req.text().then(t => {
            // Kaspi may send form-encoded data
            const params = new URLSearchParams(t);
            return Object.fromEntries(params.entries());
        });

        console.log('[Kaspi Pay Callback]', JSON.stringify(body));

        const amount = body.amount || body.Amount;
        const comment = body.comment || body.Comment || '';
        const txnId = body.txnId || body.id || body.transactionId;
        const result = body.result ?? body.status;

        // Extract order number from comment (e.g. "Заказ W-2026-0894")
        const orderMatch = comment.match(/([A-Z0-9]+-\d{4}-\d+)/);
        const orderNumber = orderMatch?.[1];

        if (!orderNumber) {
            console.warn('[Kaspi Pay] Could not extract order number from comment:', comment);
            return NextResponse.json({ result: 0, comment: 'Order not found in comment' });
        }

        const order = await prisma.order.findUnique({ where: { orderNumber } });

        if (!order) {
            console.warn('[Kaspi Pay] Order not found:', orderNumber);
            return NextResponse.json({ result: 0, comment: 'Order not found' });
        }

        // result = 0 means success in many Kaspi callback formats
        // Accept if result is 0, "0", "SUCCESS", "PAID", or not present (assume success)
        const isSuccess = result === 0 || result === '0' || result === 'SUCCESS' || result === 'PAID' || result === undefined || result === null;

        if (isSuccess) {
            await prisma.order.update({
                where: { orderNumber },
                data: {
                    paymentStatus: 'PAID',
                    status: order.status === 'PENDING_CONFIRMATION' ? 'PENDING' : order.status,
                }
            });

            await prisma.orderHistory.create({
                data: {
                    orderId: order.id,
                    action: 'PAYMENT_CONFIRMED',
                    details: `Kaspi Pay подтвердил оплату. TxnId: ${txnId}, Сумма: ${amount} ₸`
                }
            });

            console.log(`[Kaspi Pay] Order ${orderNumber} marked as PAID`);
        }

        // Kaspi expects { result: 0 } for acknowledgement (success)
        return NextResponse.json({ result: 0, comment: 'OK' });

    } catch (error) {
        console.error('[Kaspi Pay Callback Error]', error);
        // Still return 0 so Kaspi doesn't retry infinitely
        return NextResponse.json({ result: 0, comment: 'Internal error' });
    }
}

// Kaspi may also call GET to check if endpoint is alive
export async function GET() {
    return NextResponse.json({ status: 'ok', service: 'kaspi-pay-callback' });
}
