import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';
import ProductCard from '@/components/ProductCard';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

export const revalidate = 60;

async function getSaleProducts() {
    let retries = 3;
    while (retries > 0) {
        try {
            const storefrontProducts = await prisma.storefrontProduct.findMany({
                where: { 
                    isActive: true,
                    discountPrice: { not: null }
                },
                include: {
                    products: {
                        where: { quantity: { gt: 0 } },
                        orderBy: { price: 'asc' }
                    }
                },
                orderBy: { createdAt: 'desc' },
            });
            
            return storefrontProducts.filter(sp => sp.products.length > 0);
        } catch (error) {
            retries--;
            if (retries === 0) throw error;
            await new Promise(res => setTimeout(res, 1500));
        }
    }
    return [];
}

export default async function SalePage() {
    const storefrontProducts = await getSaleProducts();

    return (
        <main className="container animate-fade-in" style={{ padding: '4rem 2rem', paddingTop: '6rem' }}>
            <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                <section id="sale">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '2rem' }}>
                        <h2 style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--primary)' }}>СКИДКИ</h2>
                        <span style={{ fontSize: '1rem', opacity: 0.6 }}>{storefrontProducts.length} товаров</span>
                    </div>

                    {storefrontProducts.length === 0 ? (
                        <p style={{ opacity: 0.5 }}>В данный момент нет товаров на скидке.</p>
                    ) : (
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                            gap: '2rem'
                        }}>
                            {storefrontProducts.map((storeProduct: any) => (
                                <ProductCard key={storeProduct.id} storeProduct={storeProduct} />
                            ))}
                        </div>
                    )}
                </section>
            </div>
        </main>
    );
}
