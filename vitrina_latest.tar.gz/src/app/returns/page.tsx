import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';
import ReturnsClient from './ReturnsClient';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

export const revalidate = 60;

async function getSiteContent() {
    const content = await prisma.siteContent.findFirst();
    return content;
}

export default async function ReturnsPage() {
    const content = await getSiteContent();
    return <ReturnsClient content={content} />;
}
