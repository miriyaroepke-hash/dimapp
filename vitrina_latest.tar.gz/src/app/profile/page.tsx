import { getServerSession } from "next-auth/next";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import Link from "next/link";
import { User, Package, Clock, CheckCircle, Truck, XCircle, CreditCard } from "lucide-react";
import SignOutButton from "./SignOutButton";
import { prisma } from "@/lib/prisma";

const getStatusColor = (status: string) => {
    switch (status) {
        case 'PENDING_CONFIRMATION': return { bg: '#fff3cd', color: '#856404', text: 'Ожидает подтверждения' };
        case 'AWAITING_PAYMENT': return { bg: '#fff3cd', color: '#856404', text: 'Ожидает оплаты' };
        case 'PAID': return { bg: '#d4edda', color: '#155724', text: 'Оплачен, готовится' };
        case 'PROCESSING': return { bg: '#cce5ff', color: '#004085', text: 'В сборке' };
        case 'SENT': return { bg: '#d1ecf1', color: '#0c5460', text: 'Отправлен' };
        case 'DELIVERED': return { bg: '#d4edda', color: '#155724', text: 'Доставлен' };
        case 'CANCELLED': return { bg: '#f8d7da', color: '#721c24', text: 'Отменен' };
        default: return { bg: '#e2e3e5', color: '#383d41', text: status };
    }
};

export default async function ProfilePage() {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
        redirect("/auth/login");
    }

    const userId = (session.user as any).id;

    // Fetch user's orders
    const userOrders = await prisma.order.findMany({
        where: { customerId: userId },
        include: { items: true },
        orderBy: { createdAt: 'desc' }
    });

    const activeOrders = userOrders.filter(o => o.status !== 'DELIVERED' && o.status !== 'CANCELLED');
    const pastOrders = userOrders.filter(o => o.status === 'DELIVERED' || o.status === 'CANCELLED');

    return (
        <div style={{ minHeight: '80vh', backgroundColor: 'var(--background)', padding: '2rem 0' }}>
            <div className="container">
                <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'flex-end', justifyContent: 'space-between', gap: '1rem', marginBottom: '2rem' }}>
                    <div>
                        <h1 style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--foreground)', marginBottom: '0.2rem' }}>Личный кабинет</h1>
                        <p style={{ color: 'var(--foreground)', opacity: 0.6 }}>Управляйте своими заказами и профилем</p>
                    </div>
                    <SignOutButton />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'minmax(300px, 1fr) 2fr', gap: '2rem' }}>
                    
                    {/* Sidebar / Profile Settings */}
                    <div style={{
                        backgroundColor: 'var(--card-bg)',
                        borderRadius: 'var(--radius)',
                        border: '1px solid var(--card-border)',
                        padding: '1.5rem',
                        height: 'fit-content'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem', paddingBottom: '1.5rem', borderBottom: '1px solid var(--card-border)' }}>
                            <div style={{
                                width: '60px',
                                height: '60px',
                                backgroundColor: 'var(--background)',
                                borderRadius: '50%',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: 'var(--foreground)',
                                opacity: 0.5
                            }}>
                                <User size={30} />
                            </div>
                            <div>
                                <h2 style={{ fontSize: '1.2rem', fontWeight: 600, color: 'var(--foreground)' }}>{session.user.name || "Гость"}</h2>
                                <p style={{ fontSize: '0.9rem', color: 'var(--foreground)', opacity: 0.6 }}>{(session.user as any).phone}</p>
                            </div>
                        </div>

                        <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <Link href="/profile" style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.8rem',
                                padding: '0.8rem 1rem',
                                backgroundColor: 'var(--primary)',
                                color: 'var(--primary-foreground)',
                                borderRadius: '8px',
                                fontWeight: 500,
                            }}>
                                <Package size={18} />
                                Мои заказы
                            </Link>
                        </nav>
                    </div>

                    {/* Main Content: Orders */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        <div style={{
                            backgroundColor: 'var(--card-bg)',
                            borderRadius: 'var(--radius)',
                            border: '1px solid var(--card-border)',
                            padding: '2rem'
                        }}>
                            <h2 style={{ fontSize: '1.3rem', fontWeight: 700, marginBottom: '1.5rem' }}>Текущие заказы</h2>
                            
                            {activeOrders.length === 0 ? (
                                <div style={{
                                    textAlign: 'center',
                                    padding: '3rem 1rem',
                                    backgroundColor: 'var(--background)',
                                    borderRadius: '12px',
                                    border: '1px dashed var(--card-border)',
                                }}>
                                    <Package size={48} style={{ opacity: 0.2, margin: '0 auto 1rem auto' }} />
                                    <h3 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '0.3rem' }}>У вас пока нет активных заказов</h3>
                                    <p style={{ fontSize: '0.9rem', opacity: 0.6, marginBottom: '1.5rem' }}>Сделайте свой первый заказ, и он появится здесь.</p>
                                    <Link 
                                        href="/products" 
                                        style={{
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            padding: '0.7rem 1.5rem',
                                            backgroundColor: 'var(--primary)',
                                            color: 'var(--primary-foreground)',
                                            fontWeight: 500,
                                            borderRadius: '8px',
                                        }}
                                    >
                                        Перейти в каталог
                                    </Link>
                                </div>
                            ) : (
                                <div style={{ display: 'grid', gap: '1rem' }}>
                                    {activeOrders.map(order => {
                                        const statusObj = getStatusColor(order.status);
                                        return (
                                            <div key={order.orderNumber} style={{ border: '1px solid var(--card-border)', borderRadius: '12px', padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                                                    <div>
                                                        <h3 style={{ fontSize: '1.1rem', fontWeight: 700, marginBottom: '0.2rem' }}>Заказ {order.orderNumber}</h3>
                                                        <span style={{ fontSize: '0.85rem', opacity: 0.6 }}>{new Date(order.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                                                    </div>
                                                    <span style={{ 
                                                        backgroundColor: statusObj.bg, 
                                                        color: statusObj.color, 
                                                        padding: '0.4rem 0.8rem', 
                                                        borderRadius: '20px', 
                                                        fontSize: '0.85rem', 
                                                        fontWeight: 600 
                                                    }}>
                                                        {statusObj.text}
                                                    </span>
                                                </div>
                                                
                                                <div style={{ display: 'flex', gap: '1rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
                                                    {order.items.map(item => (
                                                        <div key={item.id} style={{ minWidth: '60px', width: '60px', height: '80px', backgroundColor: '#f5f5f5', borderRadius: '8px', overflow: 'hidden', flexShrink: 0 }}>
                                                            {item.image && <img src={item.image} alt="product" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                                                        </div>
                                                    ))}
                                                </div>

                                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderTop: '1px solid var(--card-border)', paddingTop: '1rem', marginTop: '0.5rem' }}>
                                                    <div style={{ fontSize: '0.9rem', opacity: 0.8 }}>
                                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.3rem' }}><Truck size={14} /> {order.deliveryMethod === 'CDEK' && order.cdekPvzCode ? `СДЭК ПВЗ: ${order.address}` : order.deliveryMethod}</div>
                                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}><CreditCard size={14} /> {order.paymentMethod}</div>
                                                    </div>
                                                    <div style={{ textAlign: 'right' }}>
                                                        <div style={{ fontSize: '0.85rem', opacity: 0.6, marginBottom: '0.2rem' }}>Итоговая сумма</div>
                                                        <div style={{ fontSize: '1.2rem', fontWeight: 800 }}>{order.totalAmount.toLocaleString()} ₸</div>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                        
                        <div style={{
                            backgroundColor: 'var(--card-bg)',
                            borderRadius: 'var(--radius)',
                            border: '1px solid var(--card-border)',
                            padding: '2rem'
                        }}>
                            <h2 style={{ fontSize: '1.3rem', fontWeight: 700, marginBottom: '1.5rem' }}>История заказов</h2>
                            {pastOrders.length === 0 ? (
                                <div style={{ textAlign: 'center', padding: '2rem', opacity: 0.5 }}>
                                    История пуста
                                </div>
                            ) : (
                                <div style={{ display: 'grid', gap: '1rem', opacity: 0.8 }}>
                                    {pastOrders.map(order => {
                                        const statusObj = getStatusColor(order.status);
                                        return (
                                            <div key={order.orderNumber} style={{ border: '1px solid var(--card-border)', borderRadius: '12px', padding: '1rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                                                <div>
                                                    <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '0.2rem' }}>Заказ {order.orderNumber}</h3>
                                                    <span style={{ fontSize: '0.85rem', opacity: 0.6 }}>{new Date(order.createdAt).toLocaleDateString('ru-RU')}</span>
                                                </div>
                                                <span style={{ color: statusObj.color, fontSize: '0.9rem', fontWeight: 600 }}>{statusObj.text}</span>
                                                <div style={{ fontSize: '1.1rem', fontWeight: 700 }}>{order.totalAmount.toLocaleString()} ₸</div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </div>
            {/* Fallback layout adjusting for mobile */}
            <style dangerouslySetInnerHTML={{ __html: `
                @media (max-width: 768px) {
                    .container > div:nth-child(2) {
                        grid-template-columns: 1fr !important;
                    }
                }
            `}} />
        </div>
    );
}
