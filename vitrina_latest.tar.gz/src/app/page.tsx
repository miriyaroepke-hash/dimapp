import { PrismaClient } from '@prisma/client';
import { Pool } from 'pg';
import { PrismaPg } from '@prisma/adapter-pg';
import HomeClient from './HomeClient';

const connectionString = `${process.env.DATABASE_URL}`;
const pool = new Pool({ connectionString });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

export const revalidate = 60;

async function getSiteContent() {
  let content = await prisma.siteContent.findFirst();
  // Ensure there's a default row if none exists
  if (!content) {
    content = await prisma.siteContent.create({
      data: {
        text_ru: "Curated\nCollection.",
        text_kz: "Таңдаулы\nКоллекция.",
      }
    });
  }
  return content;
}

export default async function Home() {
  const content = await getSiteContent();
  return <HomeClient content={content} />;
}


