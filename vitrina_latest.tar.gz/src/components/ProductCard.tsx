'use client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useState, useEffect } from 'react';
import { useCartStore } from '@/store/useCartStore';

interface ProductProps {
    id: number;
    name: string;
    price: number;
    oldPrice?: number | null;
    size?: string | null;
    image?: string | null;
    kaspiSku?: string | null;
    kaspiUrl?: string | null;
    halykUrl?: string | null;
}

interface StorefrontProductProps {
    id: number;
    name: string;
    description?: string | null;
    image?: string | null;
    images?: string[];
    video?: string | null;
    discountPrice?: number | null;
    products: ProductProps[];
}

export default function ProductCard({ storeProduct }: { storeProduct: StorefrontProductProps }) {
    const { t } = useLanguage();
    
    const productGroup = storeProduct.products || [];
    
    // Default to the first product in the group
    const [selectedProduct, setSelectedProduct] = useState<ProductProps>(productGroup[0] || {} as ProductProps);
    
    // Only show cart for admin
    const [isAdmin, setIsAdmin] = useState(false);
    useEffect(() => {
        setIsAdmin(localStorage.getItem('dimmianiAdmin') === 'true');
    }, []);


    const imagesList = storeProduct.images && storeProduct.images.length > 0 
        ? storeProduct.images 
        : [
            storeProduct.image && storeProduct.image.startsWith('http')
            ? storeProduct.image
            : (selectedProduct.image && selectedProduct.image.startsWith('http') 
                ? selectedProduct.image 
                : 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=800')
          ];
          
    const [currentImageIdx, setCurrentImageIdx] = useState(0);
    const [descriptionOpen, setDescriptionOpen] = useState(false);

    const imageUrl = imagesList[currentImageIdx];

    const kaspiLink = selectedProduct.kaspiUrl
        ? (selectedProduct.kaspiUrl.startsWith('http') ? selectedProduct.kaspiUrl : `https://${selectedProduct.kaspiUrl}`)
        : selectedProduct.kaspiSku
            ? `https://kaspi.kz/shop/p/${selectedProduct.kaspiSku}/`
            : null;

    const halykLink = selectedProduct.halykUrl
        ? (selectedProduct.halykUrl.startsWith('http') ? selectedProduct.halykUrl : `https://${selectedProduct.halykUrl}`)
        : null;

    return (
        <div style={{
            background: 'var(--card-bg)',
            borderRadius: 'var(--radius)',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            border: '1px solid var(--card-border)',
            transition: 'transform var(--transition), box-shadow var(--transition)',
        }}
            onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 12px 24px rgba(0,0,0,0.06)';
            }}
            onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
            }}
        >
            <div style={{
                position: 'relative',
                aspectRatio: '3/4',
                width: '100%',
                backgroundColor: '#f5f5f5',
                overflow: 'hidden'
            }}>
                <img
                    src={imageUrl}
                    alt={storeProduct.name}
                    style={{
                        objectFit: 'cover',
                        width: '100%',
                        height: '100%',
                        transition: 'transform 0.5s ease',
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                />
                
                {/* Carousel Controls */}
                {imagesList.length > 1 && (
                    <div style={{ position: 'absolute', bottom: '1rem', left: '0', right: '0', display: 'flex', justifyContent: 'center', gap: '0.25rem', zIndex: 10 }}>
                        {imagesList.map((_, idx) => (
                            <button
                                key={idx}
                                onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    setCurrentImageIdx(idx);
                                }}
                                style={{
                                    width: '8px',
                                    height: '8px',
                                    borderRadius: '50%',
                                    backgroundColor: currentImageIdx === idx ? '#fff' : 'rgba(255,255,255,0.5)',
                                    border: '1px solid rgba(0,0,0,0.1)',
                                    padding: 0,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s',
                                    transform: currentImageIdx === idx ? 'scale(1.2)' : 'scale(1)'
                                }}
                            />
                        ))}
                    </div>
                )}
                
                {/* Overlay Arrows */}
                {imagesList.length > 1 && (
                    <>
                        <button 
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setCurrentImageIdx(prev => prev === 0 ? imagesList.length - 1 : prev - 1);
                            }}
                            style={{ position: 'absolute', left: '0.5rem', top: '50%', transform: 'translateY(-50%)', background: 'rgba(255,255,255,0.7)', border: 'none', borderRadius: '50%', width: '2rem', height: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', zIndex: 10, boxShadow: '0 2px 5px rgba(0,0,0,0.1)' }}
                        >
                            &larr;
                        </button>
                        <button 
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setCurrentImageIdx(prev => prev === imagesList.length - 1 ? 0 : prev + 1);
                            }}
                            style={{ position: 'absolute', right: '0.5rem', top: '50%', transform: 'translateY(-50%)', background: 'rgba(255,255,255,0.7)', border: 'none', borderRadius: '50%', width: '2rem', height: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', zIndex: 10, boxShadow: '0 2px 5px rgba(0,0,0,0.1)' }}
                        >
                            &rarr;
                        </button>
                    </>
                )}
                
                {/* Discount Badge */}
                {storeProduct.discountPrice && (
                    <div style={{
                        position: 'absolute',
                        top: '1rem',
                        right: '1rem',
                        backgroundColor: '#ff3b30',
                        color: 'white',
                        fontWeight: 'bold',
                        fontSize: '0.75rem',
                        padding: '0.3rem 0.6rem',
                        borderRadius: '12px',
                        letterSpacing: '0.05em',
                        boxShadow: '0 4px 10px rgba(255, 59, 48, 0.4)'
                    }}>
                        СКИДКА
                    </div>
                )}
            </div>

            <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 600, marginBottom: '0.25rem', lineHeight: 1.3 }}>
                    {storeProduct.name}
                </h3>
                {storeProduct.description && (
                    <div style={{ marginBottom: '0.75rem', borderBottom: '1px solid #eee' }}>
                        <button
                            onClick={() => setDescriptionOpen(prev => !prev)}
                            style={{
                                width: '100%',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                background: 'none',
                                border: 'none',
                                padding: '0.4rem 0',
                                cursor: 'pointer',
                                fontSize: '0.875rem',
                                color: '#555',
                                fontWeight: 500,
                            }}
                        >
                            <span>Описание</span>
                            <span style={{ transition: 'transform 0.2s', transform: descriptionOpen ? 'rotate(180deg)' : 'rotate(0deg)', display: 'inline-block', fontSize: '0.75rem' }}>▼</span>
                        </button>
                        {descriptionOpen && (
                            <p style={{ fontSize: '0.85rem', color: '#555', padding: '0.5rem 0 0.75rem', margin: 0, lineHeight: 1.6 }}>
                                {storeProduct.description}
                            </p>
                        )}
                    </div>
                )}
                
                {/* Size Selector */}
                {productGroup.length > 0 && productGroup.some(p => p.size) && (
                    <div style={{ marginBottom: '1rem' }}>
                        <p style={{ fontSize: '0.875rem', opacity: 0.6, marginBottom: '0.5rem' }}>
                            {t('size')}: <span style={{ fontWeight: 'bold', color: '#000' }}>{selectedProduct.size || "Универсальный"}</span>
                        </p>
                        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                            {productGroup.map((p) => {
                                if (!p.size) return null;
                                const isSelected = p.id === selectedProduct.id;
                                return (
                                    <button
                                        key={p.id}
                                        onClick={() => setSelectedProduct(p)}
                                        style={{
                                            padding: '0.4rem 0.8rem',
                                            borderRadius: '6px',
                                            border: `1px solid ${isSelected ? '#111' : '#ddd'}`,
                                            backgroundColor: isSelected ? '#111' : '#fff',
                                            color: isSelected ? '#fff' : '#111',
                                            fontSize: '0.875rem',
                                            fontWeight: 500,
                                            cursor: 'pointer',
                                            transition: 'all 0.2s',
                                        }}
                                    >
                                        {p.size}
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Price Display */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: 'auto', marginBottom: '1.25rem' }}>
                    {storeProduct.discountPrice ? (
                        <>
                            <p style={{ fontSize: '1.25rem', fontWeight: 800, color: '#ff3b30', margin: 0 }}>
                                {storeProduct.discountPrice.toLocaleString('ru-RU')} ₸
                            </p>
                            {selectedProduct.oldPrice ? (
                                <p style={{ fontSize: '1rem', fontWeight: 500, color: '#999', textDecoration: 'line-through', margin: 0 }}>
                                    {selectedProduct.oldPrice.toLocaleString('ru-RU')} ₸
                                </p>
                            ) : null}
                        </>
                    ) : (
                        <p style={{ fontSize: '1.125rem', fontWeight: 500, margin: 0 }}>
                            {selectedProduct.price ? `${selectedProduct.price.toLocaleString('ru-RU')} ₸` : 'Нет в наличии'}
                        </p>
                    )}
                </div>

                <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                    {isAdmin && (
                    <button
                        onClick={() => {
                            useCartStore.getState().addItem({
                                id: `${selectedProduct.id}-${selectedProduct.size || 'uni'}`,
                                productId: selectedProduct.id,
                                name: storeProduct.name,
                                price: storeProduct.discountPrice || selectedProduct.price,
                                size: selectedProduct.size || null,
                                quantity: 1,
                                image: imageUrl,
                                kaspiSku: selectedProduct.kaspiSku
                            });
                        }}
                        style={{
                            flex: 1,
                            textAlign: 'center',
                            backgroundColor: '#000',
                            color: 'white',
                            padding: '0.6rem',
                            borderRadius: '8px',
                            fontSize: '0.875rem',
                            fontWeight: 600,
                            border: 'none',
                            cursor: 'pointer'
                        }}
                    >
                        {t('add_to_cart')}
                    </button>
                    )}
                </div>
                
                <a
                    href="https://api.whatsapp.com/send/?phone=77477677124&text&type=phone_number&app_absent=0&utm_source=ig"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                        display: 'block',
                        marginTop: '0.75rem',
                        textAlign: 'center',
                        backgroundColor: '#25D366', // WhatsApp green
                        color: 'white',
                        padding: '0.6rem',
                        borderRadius: '8px',
                        fontSize: '0.875rem',
                        fontWeight: 600,
                        textDecoration: 'none'
                    }}
                >
                    {t('order_whatsapp')}
                </a>

                {storeProduct.video && (
                    <a
                        href={storeProduct.video}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                            display: 'flex',
                            marginTop: '0.5rem',
                            textAlign: 'center',
                            backgroundColor: '#E1306C',
                            color: 'white',
                            padding: '0.6rem',
                            borderRadius: '8px',
                            fontSize: '0.875rem',
                            fontWeight: 600,
                            textDecoration: 'none',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '0.5rem'
                        }}
                    >
                        Смотреть Обзор
                    </a>
                )}
            </div>
        </div>
    );
}
